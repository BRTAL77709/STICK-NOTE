import React from 'react';
import {AbsoluteFill,Composition,registerRoot,staticFile,useCurrentFrame} from 'remotion';
import {Driving,Rain} from './Driving';
import {SkinDefs,PaintedActor,Gun} from './Skin';
import {actorPose,footTrack,ease} from './motion';
import {runState} from './run';
function Criminal({t}:any){
 const turn=ease((t-.45)/1.1),reaction=ease((t-1.35)/.45);
 const p=actorPose({t,x:530,ground:1510,s:1.7,left:footTrack(t,488,[],1510,1.7),right:footTrack(t,571,[],1510,1.7),lean:-2+3*ease((t-.7)/1.2),head:-8*(1-turn)+reaction*3,look:-1+turn,up:0,fear:0});
 return <><image href={staticFile('assets/alley.png')} width='1080' height='1920' preserveAspectRatio='xMidYMid slice'/><Rain t={t}/><PaintedActor p={p} id='criminal' criminal yaw={-1.25*(1-turn)} headExtra={-3*Math.sin(Math.PI*turn)}/><Gun hand={p.rightArm.end} s={1.7}/></>;
}
function Run({t}:any){let p=runState(t),camera=-(p.x-450);return <><image href={staticFile('assets/street.png')} width='1080' height='1920' preserveAspectRatio='xMidYMid slice'/><g transform={`translate(${camera} 0)`}>
 {Array.from({length:18},(_,i)=><g key={i}><path d={`M${i*180-500} 1570 l80 -12`} stroke='#ad996a' strokeWidth='3' opacity='.35'/><ellipse cx={i*180-490} cy='1640' rx='30' ry='3' fill='#78919d' opacity='.15'/></g>)}
 <PaintedActor p={p} id='run' view={.9} yaw={.75}/></g><Rain t={t+9}/></>}
function Test(){let t=useCurrentFrame()/30;let label=t<6?'DRIVING / MIRROR GLANCE':t<9?'CRIMINAL / HEAD TURN':'RUN / HUMAN MOCAP RETARGET';return <AbsoluteFill style={{background:'#040b14'}}><svg width='1080' height='1920' viewBox='0 0 1080 1920'><SkinDefs/>{t<6?<Driving t={t} panic showPursuer/>:t<9?<Criminal t={t-6}/>:<Run t={t-9}/>}
 <rect y='0' width='1080' height='95' fill='#020710'/><text x='540' y='58' textAnchor='middle' fontFamily='DejaVu Sans' fontSize='26' letterSpacing='3' fill='#e5e2d9'>THE PRICE OF SILENCE — MOTION TEST</text>
 <rect y='1770' width='1080' height='150' fill='#020710' opacity='.9'/><text x='540' y='1825' textAnchor='middle' fontFamily='DejaVu Sans' fontSize='24' letterSpacing='2' fill='#d0b18b'>{label}</text><text x='540' y='1875' textAnchor='middle' fontFamily='DejaVu Sans' fontSize='19' fill='#8ba2b1'>MOVEMENT REVIEW ONLY — FULL FILM ON HOLD</text>
 </svg></AbsoluteFill>}
registerRoot(()=> <Composition id='MovementTest' component={Test} durationInFrames={450} fps={30} width={1080} height={1920}/>);
