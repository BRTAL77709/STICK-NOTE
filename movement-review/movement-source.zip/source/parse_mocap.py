from pathlib import Path
import re,json,numpy as np
P=Path(__file__).resolve().parents[1]
s=(P/'reference/02_03.bvh').read_text();h,m=s.split('MOTION');tokens=re.findall(r'[{}]|[^\s{}]+',h);i=1;nodes=[];channel=0

def parse(parent=-1):
 global i,channel
 kind=tokens[i];i+=1
 name=tokens[i] if kind!='End' else 'End'+str(len(nodes));i+=1
 assert tokens[i]=='{';i+=1;n=len(nodes);nodes.append({'name':name,'parent':parent,'offset':[0,0,0],'channels':[],'index':channel})
 while tokens[i]!='}':
  if tokens[i]=='OFFSET':nodes[n]['offset']=list(map(float,tokens[i+1:i+4]));i+=4
  elif tokens[i]=='CHANNELS':
   count=int(tokens[i+1]);nodes[n]['channels']=tokens[i+2:i+2+count];nodes[n]['index']=channel;channel+=count;i+=2+count
  else:parse(n)
 i+=1
parse()
lines=m.strip().splitlines();dt=float(lines[1].split(':')[1]);data=np.array([list(map(float,l.split())) for l in lines[2:] if l.strip()]);out=[]
def rot(axis,a):
 a=np.deg2rad(a);c=np.cos(a);s=np.sin(a)
 return np.array([[1,0,0],[0,c,-s],[0,s,c]]) if axis=='X' else np.array([[c,0,s],[0,1,0],[-s,0,c]]) if axis=='Y' else np.array([[c,-s,0],[s,c,0],[0,0,1]])
for row in data:
 positions=[];rots=[]
 for n in nodes:
  p=np.array(n['offset'],float);r=np.eye(3)
  for c,v in zip(n['channels'],row[n['index']:]):
   if c.endswith('position'):p['XYZ'.index(c[0])]+=v
   else:r=r@rot(c[0],v)
  if n['parent']>=0:
   j=n['parent'];p=positions[j]+rots[j]@p;r=rots[j]@r
  positions.append(p);rots.append(r)
 out.append({n['name']:positions[j].tolist() for j,n in enumerate(nodes) if not n['name'].startswith('End')})
(P/'source/mocap.json').write_text(json.dumps({'dt':dt,'frames':out},separators=(',',':')))
a=np.array([f['Hips'] for f in out]);print('duration',len(data)*dt,'root',a[0],a[-1]);
for key in ['LeftFoot','RightFoot','LeftToeBase','LeftHand','Head']:
 a=np.array([f[key] for f in out]);print(key,'min',a.min(0),'max',a.max(0))
