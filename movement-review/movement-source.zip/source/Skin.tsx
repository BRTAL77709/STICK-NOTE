import React from 'react';
import {staticFile} from 'remotion';
import atlas from './atlas.json';
import {P,sub,len} from './motion';
export function Part({n,x=0,y=0,w,h,vehicle=false,rotate=0,rect}:any){
 const a=vehicle?atlas.vehicle:atlas.rig,b=rect||a.parts[n];
 return <svg x={x} y={y} width={w} height={h} viewBox={b.join(' ')} preserveAspectRatio="none" overflow="hidden"><g transform={rotate?`rotate(${rotate} ${b[0]+b[2]/2} ${b[1]+b[3]/2})`:undefined}><image href={staticFile(`assets/${vehicle?'vehicle':'rig'}.png`)} width={a.width} height={a.height}/></g></svg>;
}
export function SkinDefs(){return <defs>
 <linearGradient id="faceSkin" x2="1" y2="1"><stop stopColor="#f4eade"/><stop offset="1" stopColor="#94b3b8"/></linearGradient>
 <linearGradient id="clothMask" x2="1" y2="1"><stop stopColor="#17222b"/><stop offset="1" stopColor="#050b12"/></linearGradient>
 <radialGradient id="glowWarm"><stop stopColor="#ffd19a" stopOpacity=".30"/><stop offset="1" stopColor="#ffc58c" stopOpacity="0"/></radialGradient>
 <radialGradient id="glowCold"><stop stopColor="#b8e8f5" stopOpacity=".33"/><stop offset="1" stopColor="#a1def7" stopOpacity="0"/></radialGradient>
 <radialGradient id="vignette"><stop offset=".4" stopColor="#02060d" stopOpacity="0"/><stop offset="1" stopColor="#01040a" stopOpacity=".50"/></radialGradient>
 <filter id="victimCloth"><feColorMatrix type="matrix" values=".4 0 0 0 .24 0 .4 0 0 .24 0 0 .4 0 .24 0 0 0 1 0"/></filter>
 <clipPath id="torsoShape"><path d="M-46 53 Q0 37 48 53 L69 230 Q0 263 -69 230Z"/></clipPath>
 <clipPath id="victimFace"><ellipse rx="59" ry="63"/></clipPath>
 </defs>}
export function Face({t,look=0,up=0,fear=0,view=0,criminal=false,victim=false,yaw=0}:any){
 const blink=t%4.15<.13?.08:1;
 return <g transform={`translate(${Math.sin(yaw)*24} 0) matrix(${Math.cos(yaw)*.6+.4} ${Math.sin(yaw)*.055} ${Math.sin(yaw)*.035} 1 0 0)`}>
 {victim?<g><ellipse rx="59" ry="63" fill="url(#faceSkin)"/><svg x="-59" y="-63" width="118" height="126" viewBox="64 165 165 94" preserveAspectRatio="none"><image href={staticFile('assets/rig.png')} width={atlas.rig.width} height={atlas.rig.height}/></svg></g>:<>
 <Part n={0} x={-80} y={-100} w={175} h={170}/>
 </>}
 {criminal&&<path d="M-58 -4 Q0 -16 59 -4 L55 56 Q0 76 -54 54Z" fill="url(#clothMask)" stroke="#304451" strokeWidth="2"/>}
 {criminal&&<path d="M-42 4 Q0 -3 43 4 L38 26 Q0 32 -39 25Z" fill="#c7ccc6"/>}
 {victim?<><path d="M-28 10 q11 9 22 1 M12 12 q11 7 20 -2" stroke="#38444a" strokeWidth="4" fill="none"/><path d="M-9 38 q13 -4 20 3" stroke="#66565a" strokeWidth="3" fill="none"/></>:<>
 <ellipse opacity={yaw>0?Math.max(.08,1-yaw*.7):1} cx={-20+look*9+Math.sin(yaw)*14} cy={13-up*9} rx={5.5+fear*1.5} ry={(9+fear*2)*blink} fill="#101721"/>
 <ellipse opacity={yaw<0?Math.max(.08,1+yaw*.7):1} cx={22+look*9+Math.sin(yaw)*14} cy={13-up*9} rx={5.5+fear*1.5} ry={(9+fear*2)*blink} fill="#101721"/>
 <path d={`M-32 ${-3-fear*6} L-10 ${-4-fear*6} M12 ${-4-fear*6} L34 ${-3-fear*6}`} stroke={criminal?'#0b121b':'#38424a'} strokeWidth="3.5"/>
 {!criminal&&<path d={fear>.4?'M-8 43 Q2 35 15 42':'M-8 42 Q3 38 13 42'} stroke="#4c5159" strokeWidth="3" fill="none"/>}
 {!criminal&&fear>.5&&<path d="M-42 18 q-11 18 0 21 q11 -2 0 -21Z" fill="#6c9db3" opacity=".7"/>}
 </>}
 </g>
}
function Segment({a,b,n,width}:any){let d=sub(b,a),angle=Math.atan2(d.y,d.x)*180/Math.PI-90;return <g transform={`translate(${a.x} ${a.y}) rotate(${angle})`}><Part n={n} x={-width/2} y={-6} w={width} h={len(d)+12}/></g>}
function Hand({p,angle,s,left=false}:any){return <g transform={`translate(${p.x} ${p.y}) rotate(${angle})`}><Part n={left?12:13} x={-14*s} y={-17*s} w={28*s} h={35*s}/></g>}
export function PaintedActor({p,id='actor',criminal=false,victim=false,view=0,headExtra=0,opacity=1,yaw=0}:any){
 const {s,ground,root}=p,armA=(b:any)=>Math.atan2(b.end.y-b.joint.y,b.end.x-b.joint.x)*180/Math.PI-90;
 const bodyMatrix=`translate(${root.x} ${root.y}) scale(${s}) rotate(${p.lean*180/Math.PI} 0 237)`;
 return <g opacity={opacity}>
 <ellipse cx={p.x+15*s} cy={ground+2*s} rx={110*s} ry={12*s} fill="#01060c" opacity=".58"/>
 <Segment a={p.leftLeg.a} b={p.leftLeg.joint} n={14} width={27*s}/><Segment a={p.leftLeg.joint} b={p.leftLeg.end} n={16} width={25*s}/>
 <Segment a={p.rightLeg.a} b={p.rightLeg.joint} n={15} width={27*s}/><Segment a={p.rightLeg.joint} b={p.rightLeg.end} n={17} width={25*s}/>
 {[p.left,p.right].map((f:any,i:number)=><g key={i} transform={`translate(${f.heel.x} ${f.heel.y}) rotate(${Math.atan2(f.toe.y-f.heel.y,f.toe.x-f.heel.x)*180/Math.PI})`}><Part n={i?19:18} x={-11.5*s} y={-20*s} w={59*s} h={31.5*s}/></g>)}
 <g filter={victim?'url(#victimCloth)':undefined}>
 <g transform={bodyMatrix} clipPath="url(#torsoShape)"><Part n={view>.5?5:4} x={-90} y={45} w={180} h={218}/>{victim&&<path d="M-6 110 q22 -15 30 16 l-8 54 l-25 -10Z" fill="#5c2c32" opacity=".85"/>}</g>
 <Segment a={p.leftArm.a} b={p.leftArm.joint} n={8} width={35*s}/><Segment a={p.leftArm.joint} b={p.leftArm.end} n={10} width={32*s}/>
 <Segment a={p.rightArm.a} b={p.rightArm.joint} n={9} width={35*s}/><Segment a={p.rightArm.joint} b={p.rightArm.end} n={11} width={32*s}/>
 </g>
 {victim&&<g transform={bodyMatrix}><path d="M-6 110 q22 -15 30 16 l-8 54 l-25 -10Z" fill="#6d2831" opacity=".88"/></g>}
 <Hand p={p.leftArm.end} s={s} angle={armA(p.leftArm)} left/><Hand p={p.rightArm.end} s={s} angle={armA(p.rightArm)}/>
 <g transform={bodyMatrix}><g transform={`rotate(${(p.head||0)+headExtra})`}><Face t={p.t} look={p.look||0} up={p.up||0} fear={p.fear||0} criminal={criminal} victim={victim} view={view} yaw={yaw}/></g></g>
 </g>
}
export function Gun({hand,s=.8}:any){return <g transform={`translate(${hand.x} ${hand.y}) rotate(23) scale(${s})`}>
 <path d="M-12 -17 H53 V-5 H27 L19 29 H1 L5 -1 H-12Z" fill="#121a24" stroke="#7c8a92" strokeWidth="2"/>
 <path d="M-7 -13 H49 M20 -4 Q31 10 16 16" stroke="#394955" strokeWidth="3" fill="none"/>
 <path d="M0 2 l14 3 m-16 3 l13 3" stroke="#d7d9ca" strokeWidth="4" strokeLinecap="round"/>
 </g>}
