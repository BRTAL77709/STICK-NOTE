const fs=require('fs'),m=require('../output/run.cjs');let maxReach=0,maxPinDrift=0,prev={},footfalls=[],maxJointJump=0;
for(let f=0;f<720;f++){
 let t=f/120,p=m.runState(t);
 for(let k of ['leftArm','rightArm','leftLeg','rightLeg']){let b=p[k];maxReach=Math.max(maxReach,b.error);if(prev[k])maxJointJump=Math.max(maxJointJump,Math.hypot(b.joint.x-prev[k].x,b.joint.y-prev[k].y));prev[k]=b.joint;}
 for(let k of ['left','right']){let a=p[k],b=prev[k];if(a.planted&&b?.planted)maxPinDrift=Math.max(maxPinDrift,Math.hypot(a.heel.x-b.heel.x,a.heel.y-b.heel.y));if(a.planted&&!b?.planted)footfalls.push(t);prev[k]=a;}
}
fs.writeFileSync('/workspace/movement-test/output/footfalls.json',JSON.stringify(footfalls));let report={...m.runMetadata,maxReach,maxPinDrift,maxJointJump,footfalls,review:'Pending rendered-motion and user review; not a realism certification.'};fs.writeFileSync('/workspace/movement-test/output/rig-qc.json',JSON.stringify(report,null,2));console.log(report);
