from pathlib import Path
import subprocess,json,hashlib,zipfile
P=Path(__file__).resolve().parents[1];O=P/'output'
def run(a):return subprocess.run(a,check=True,capture_output=True,text=True).stdout
run(['ffmpeg','-v','error','-y','-i',str(O/'picture.mp4'),'-i',str(O/'test_mix.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','128k','-af','loudnorm=I=-19:TP=-1.5:LRA=8','-t','15','-movflags','+faststart',str(O/'movement-test.mp4')])
probe=json.loads(run(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(O/'movement-test.mp4')]))
v=next(s for s in probe['streams'] if s['codec_type']=='video');a=next(s for s in probe['streams'] if s['codec_type']=='audio')
assert(v['width'],v['height'],v['r_frame_rate'],int(v['nb_read_frames']),v['codec_name'],a['codec_name'])==(1080,1920,'30/1',450,'h264','aac')
assert abs(float(probe['format']['duration'])-15)<.01
run(['ffmpeg','-v','error','-i',str(O/'movement-test.mp4'),'-f','null','-'])
md5=run(['ffmpeg','-v','error','-i',str(O/'movement-test.mp4'),'-an','-f','framemd5','-']);frames=[x.rsplit(',',1)[-1].strip() for x in md5.splitlines() if not x.startswith('#') and x.strip()]
assert len(frames)==450;duplicates=sum(a==b for a,b in zip(frames,frames[1:]));assert duplicates==0
run(['ffmpeg','-v','error','-y','-i',str(O/'movement-test.mp4'),'-vf','fps=4,scale=135:240,tile=10x6','-frames:v','1',str(O/'motion-sheet.jpg')])
q=json.loads((O/'rig-qc.json').read_text());q.update({'export':{'width':1080,'height':1920,'fps':30,'frames':450,'duration_seconds':15,'video':'H.264','audio':'AAC','full_decode':'passed','adjacent_identical_decoded_frames':duplicates},'file':{'bytes':(O/'movement-test.mp4').stat().st_size,'sha256':hashlib.sha256((O/'movement-test.mp4').read_bytes()).hexdigest()},'limits':'No human real-time playback or listening certification is claimed. Existing painted assets are an earlier approximation; exact locked-art fidelity and naturalness remain unapproved.'})
(O/'verification.json').write_text(json.dumps(q,indent=2))
with zipfile.ZipFile(O/'movement-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for base in ['source','reference','public']:
  for p in (P/base).rglob('*'):
   if p.is_file() and 'node_modules' not in p.parts:z.write(p,p.relative_to(P))
 z.write(P/'README.md','README.md')
 for f in ['verification.json','sound-events.json','footfalls.json']:z.write(O/f,'output/'+f)
print(json.dumps(q['file']),flush=True)
