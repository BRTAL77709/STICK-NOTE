import data from './mocap.json';
import {actorPose,P,ease,blend,clamp} from './motion';
const start=24,period=92,dt=data.dt,scale=10,s=1.5,G=1510,speed=(data.frames[116].Hips[2]-data.frames[24].Hips[2])/(period*dt)*6.5*s;
function sample(t:number,key:string){
 let f=(t/dt)%period,idx=start+f,i=Math.floor(idx),q=idx-i;
 const src=(data.frames as any[]),at=(j:number)=>src[j][key].map((v:number,k:number)=>v-src[j].Hips[k]);
 let a=at(i),b=at(i+1),v=a.map((x:number,k:number)=>blend(x,b[k],q));
 // Smooth the small capture discontinuity over the seam in joint-local space.
 if(f>period-10){let first=at(start),last=at(start+period),w=ease((f-period+10)/10);v=v.map((x:number,k:number)=>x+(first[k]-last[k])*w);}
 return v;
}
function rootAt(t:number){return 380+speed*t;}
function raw(t:number,side:string){
 let foot=sample(t,side+'Foot'),toe=sample(t,side+'ToeBase');
 return {x:rootAt(t)+foot[2]*6.5*s,y:G-11.5*s-Math.max(0,Math.min(foot[1]+16,toe[1]+16))*scale*s};
}
// Reference contact candidates use low toe height and low ground-relative horizontal speed.
// Each stance stores a world-space pin. Swing endpoints blend into that pin.
const N=720,rate=120;
const tracks:any={Left:[],Right:[]};
for(const side of ['Left','Right']){
 const rawTrack:any[]=[],contact:boolean[]=[];
 for(let i=0;i<=N+120;i++){
  let t=i/rate,v=sample(t,side+'ToeBase'),v2=sample(t+.01,side+'ToeBase');
  let height=v[1]+16,worldVel=(v2[2]-v[2])*6.5*s/.01+speed;
  contact.push(height<2.5&&Math.abs(worldVel)<speed*.65);rawTrack.push(raw(t,side));
 }
 const pins:any[]=[];
 for(let i=0;i<contact.length;){if(!contact[i]){i++;continue;}let a=i;while(i<contact.length&&contact[i])i++;let b=i-1;let x=rawTrack.slice(a,b+1).reduce((v,p)=>v+p.x,0)/(b-a+1);pins.push({a,b,x});}
 for(let i=0;i<=N;i++){
  const current=pins.find(p=>i>=p.a&&i<=p.b);let p:P,plant=!!current;
  if(current)p={x:current.x,y:G-11.5*s};
  else{
   let prev=[...pins].reverse().find(p=>p.b<i),next=pins.find(p=>p.a>i);
   const a=prev?.b??0,b=next?.a??N+120,q=clamp((i-a)/(b-a)),from=prev?.x??rawTrack[a].x,to=next?.x??rawTrack[b].x;
   const base=G-11.5*s,ha=base-rawTrack[a].y,hb=base-rawTrack[b].y;
   const lift=Math.max(0,base-rawTrack[i].y-blend(ha,hb,q));
   p={x:blend(from,to,ease(q)),y:base-lift*Math.sin(Math.PI*q)**.5};
  }
  tracks[side].push({heel:p,ankle:p,toe:{x:p.x+36*s,y:p.y},planted:plant,contact:plant?{x:p.x,y:G}:null,phase:plant?'stance':'swing'});
 }
}
export function runState(t:number){
 t=clamp(t,0,5.99);const index=Math.floor(t*rate),q=t*rate-index;
 const foot=(side:string)=>{let a=tracks[side][index],b=tracks[side][index+1],p={x:blend(a.heel.x,b.heel.x,q),y:blend(a.heel.y,b.heel.y,q)};return {...a,heel:p,ankle:p,toe:{x:p.x+36*s,y:p.y}};};
 const L=foot('Left'),R=foot('Right'),sp=sample(t,'Spine1');
 const x=rootAt(t),p=actorPose({t,x,ground:G,s,left:L,right:R,lean:12+sp[2]*.3,head:-3,look:1,fear:.7,run:true});
 // Retarget the recorded bent-elbow hand arcs to the existing short-limbed design.
 // Source shoulder/wrist directions, rather than sine waves, drive each arm.
 const hand=(side:string,sign:number)=>{
  let a=sample(t,side+'Arm'),h=sample(t,side+'Hand');
  return p.body({x:sign*44+(h[2]-a[2])*10,y:92-(h[1]-a[1])*10});
 };
 return actorPose({t,x,ground:G,s,left:L,right:R,lean:12+sp[2]*.3,head:-3+sample(t,'Head')[2]*.1,look:1,fear:.7,run:true,leftHand:hand('Left',-1),rightHand:hand('Right',1)});
}
export const runMetadata={source:'CMU 02_03 running, BVH conversion by Bruce Hahne',sourceRate:1/dt,cycleFrames:period,rootSpeedPxPerSecond:speed,style:'Original painted sprite parts; no new artwork generated.'};
