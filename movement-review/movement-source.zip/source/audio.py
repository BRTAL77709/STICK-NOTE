from pathlib import Path
import numpy as np,soundfile as sf,json
P=Path(__file__).resolve().parents[1];S=48000;D=15;r=np.random.default_rng(217);t=np.arange(S*D)/S
mix=np.zeros((len(t),2));events=[]
noise=np.convolve(r.normal(0,1,len(t)),np.ones(15)/15,mode='same')*.024
mix+=noise[:,None]
engine=(.019*np.sin(2*np.pi*(42*t+5*t*t))+.007*np.sin(2*np.pi*85*t))*np.clip((6-t)/.15,0,1)
mix+=engine[:,None]
def hit(at,d=.15):
 q=np.arange(int(d*S))/S;a=(.1*np.sin(2*np.pi*90*q)+r.normal(0,.017,len(q)))*np.exp(-32*q);i=round(at*S);n=min(len(a),len(mix)-i);mix[i:i+n]+=a[:n,None];events.append(at)
# Event times are supplied by actual stance transitions from the retargeted rig.
for at in json.loads((P/'output/footfalls.json').read_text()):hit(9+at)
for at in [2.4,3.5,4.6,9.4,10.2,11,11.8,12.6,13.4,14.2]:
 q=np.arange(int(.4*S))/S;a=np.convolve(r.normal(0,1,len(q)),np.ones(20)/20,mode='same')*.02*np.sin(np.pi*q/.4)**2;i=round(at*S);mix[i:i+len(a)]+=a[:,None]
fade=np.minimum(t/.15,1)*np.minimum((D-t)/.2,1);mix*=fade[:,None];sf.write(P/'output/test_mix.wav',mix,S,subtype='PCM_24');(P/'output/sound-events.json').write_text(json.dumps({'footfalls':events,'note':'No new dialogue or story content; this is an isolated movement test.'},indent=2))
