from pathlib import Path
import subprocess,json,hashlib,base64,urllib.request
P=Path(__file__).resolve().parents[1];O=P/'output';repo='repos/BRTAL77709/STICK-NOTE';branch='movement-test'
def api(path,data=None):
 args=['gh','api',repo+'/'+path]
 if data is not None:args+=['--method','POST','--input','-']
 r=subprocess.run(args,input=json.dumps(data) if data is not None else None,capture_output=True,text=True)
 if r.returncode:raise RuntimeError(r.stderr.strip())
 return json.loads(r.stdout)
# Create a new branch only; refuse to overwrite any existing branch.
r=subprocess.run(['gh','api',repo+'/git/ref/heads/'+branch],capture_output=True,text=True)
if r.returncode==0:raise RuntimeError('Branch already exists; refusing overwrite')
if '404' not in r.stderr:raise RuntimeError(r.stderr.strip())
parent=api('git/ref/heads/main')['object']['sha'];treebase=api('git/commits/'+parent)['tree']['sha'];entries=[]
for name in ['movement-test.mp4','movement-source.zip','verification.json','motion-sheet.jpg']:
 p=O/name;b=p.read_bytes();blob=api('git/blobs',{'content':base64.b64encode(b).decode(),'encoding':'base64'})
 assert blob['sha']==hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 entries.append({'path':'movement-review/'+name,'mode':'100644','type':'blob','sha':blob['sha']})
p=P/'README.md';b=p.read_bytes();blob=api('git/blobs',{'content':base64.b64encode(b).decode(),'encoding':'base64'});entries.append({'path':'movement-review/README.md','mode':'100644','type':'blob','sha':blob['sha']})
tree=api('git/trees',{'base_tree':treebase,'tree':entries})['sha'];commit=api('git/commits',{'message':'Add isolated 15-second articulated movement test for review','tree':tree,'parents':[parent]})['sha'];api('git/refs',{'ref':'refs/heads/'+branch,'sha':commit})
assert api('git/ref/heads/main')['object']['sha']==parent
results=[]
for name in ['movement-test.mp4','movement-source.zip','verification.json','motion-sheet.jpg']:
 u=f'https://raw.githubusercontent.com/BRTAL77709/STICK-NOTE/{commit}/movement-review/{name}'
 with urllib.request.urlopen(u) as response:b=response.read();status=response.status
 orig=(O/name).read_bytes();assert status==200 and b==orig
 results.append({'name':name,'url':u,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'http_status':status})
(O/'download-links.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
