import React from 'react';
import {staticFile} from 'remotion';
import {Part,Face} from './Skin';
import {P,twoBone,ease,blend,sub,len} from './motion';
const Txt=({x,y,children,...props}:any)=><text x={x} y={y} fontFamily='DejaVu Sans' fill='#c1cdd0' fontSize='25' {...props}>{children}</text>;
export function Rain({t,amount=1}:any){return <g opacity={.2*amount}>{Array.from({length:90},(_,i)=>{let x=(i*131)%1120,y=(i*179+t*600)%2000-60;return <path key={i} d={`M${x} ${y} l-5 34`} stroke='#b9d6e8' strokeWidth='1'/>})}</g>}
export function Driving({t,panic=false,showPursuer=panic,stopped=false,lookSide=false}:any){
 const S=2.6,root={x:330,y:820+Math.sin(t*(panic?5:2))*2},up=lookSide?0:ease((t-.4)/.6)*(1-ease((t-2.8)/.6)),fear=panic?ease(t/.6):.12;
 const angle=(Math.sin(t*.7)*4+(panic?ease((t-2.0)/.7)*-22:0))*Math.PI/180;
 const wheel={x:760,y:1365,r:220},grip=(a:number)=>({x:wheel.x+Math.cos(a+angle)*wheel.r,y:wheel.y+Math.sin(a+angle)*wheel.r});
 const left=grip(-2.5),right=grip(-.65),shoulders=[{x:root.x-44*S,y:root.y+92*S},{x:root.x+44*S,y:root.y+92*S}];
 const arms=[twoBone(shoulders[0],left,110*S,115*S,{x:300,y:1400},1),twoBone(shoulders[1],right,110*S,115*S,{x:650,y:1400},1)];
 const gap=panic?blend(16,9,ease(t/4)):25;
 return <g>
 <image href={staticFile('assets/street.png')} width="1080" height="1920" preserveAspectRatio="xMidYMid slice"/>
 <g transform={`translate(${Math.sin(t*.5)*4} ${stopped?0:-t*(panic?32:12)})`} opacity=".8"><image href={staticFile('assets/street.png')} width="1080" height="2100" preserveAspectRatio="xMidYMid slice"/></g>
 <Rain t={t} amount={.6}/>
 <image href={staticFile('assets/cabin.png')} width="1080" height="1920" preserveAspectRatio="none"/>
 <g transform={`translate(${root.x} ${root.y}) scale(${S})`}><clipPath id="driverTorso"><path d="M-46 53 Q0 37 48 53 L69 230 Q0 263 -69 230Z"/></clipPath><g clipPath="url(#driverTorso)"><Part n={6} x={-90} y={45} w={180} h={218}/></g><g transform={`rotate(${-5*up})`}><Face yaw={up*.85} t={t+1} look={lookSide?1:.2+up*.55} up={up} fear={fear} view={.85-up*.5}/></g></g>
 <path d="M175 1000 L650 1510" stroke="#18222e" strokeWidth="39"/><path d="M175 1000 L650 1510" stroke="#4b5965" strokeWidth="5" opacity=".4"/>
 {arms.map((a,i)=>{let seg=(p:P,q:P,n:number)=>{let d=sub(q,p);return <g transform={`translate(${p.x} ${p.y}) rotate(${Math.atan2(d.y,d.x)*180/Math.PI-90})`}><Part n={n} x={-17*S} y={-12} w={34*S} h={len(d)+24}/></g>};return <g key={i}>{seg(a.a,a.joint,i?9:8)}{seg(a.joint,a.end,i?11:10)}</g>})}
 <g transform={`translate(${wheel.x} ${wheel.y}) rotate(${angle*180/Math.PI})`}><Part n={7} vehicle x={-wheel.r} y={-wheel.r} w={wheel.r*2} h={wheel.r*2}/></g>
 {[left,right].map((p,i)=><g key={i} transform={`translate(${p.x} ${p.y}) rotate(${angle*180/Math.PI+(i?30:-25)})`}><Part n={i?13:12} x={-14*S} y={-17*S} w={28*S} h={35*S}/></g>)}
 <defs><clipPath id="reflect"><rect x="518" y="391" width="484" height="130" rx="23"/></clipPath><mask id="mirrorRing"><rect x="490" y="320" width="535" height="250" fill="white"/><rect x="518" y="391" width="484" height="130" rx="23" fill="black"/></mask></defs>
 <g clipPath="url(#reflect)"><image href={staticFile('assets/street.png')} x="510" y="-500" width="500" height="1100" preserveAspectRatio="none"/><rect x="510" y="380" width="500" height="150" fill="#071b2c" opacity=".35"/>
 {[0,1,2,3].map(i=><path key={i} d={`M760 ${400+((i*31-t*(panic?50:24))%120+120)%120} v10`} stroke="#b2beb4" strokeWidth="3" opacity=".5"/>)}
 {showPursuer&&<g><Part n={2} vehicle x={760-1500/gap} y={469-1000/gap} w={3000/gap} h={1850/gap}/><ellipse cx={760-750/gap} cy="480" rx={360/gap} ry={250/gap} fill="url(#glowCold)"/><ellipse cx={760+750/gap} cy="480" rx={360/gap} ry={250/gap} fill="url(#glowCold)"/></g>}
 </g><g mask="url(#mirrorRing)"><Part n={8} vehicle x={490} y={320} w={535} h={250}/></g>
 <ellipse cx={1050-(t*220)%1300} cy="900" rx="170" ry="520" fill="url(#glowWarm)" opacity=".16"/>
 <Txt x={80} y={1720} size={25} fill="#91bdc9" letterSpacing="5">02:17 AM</Txt>
 </g>
}