# THE PRICE OF SILENCE — cinematic overhaul preview

The current deliverable is a 20-second approval preview, not a complete film.
The baseline at `/workspace/chase-film` is preserved unchanged. Working files
are in `/workspace/chase-overhaul`. No generated stills replace the character.

## Asset and implementation map

| Baseline | Current preview implementation |
|---|---|
| Head/cap/face, hoodie path art | OriginalArt.tsx / Character.tsx: same source art and dimensions |
| Rig sinusoidal limb offsets | motion.ts: planted foot tracks, heel/toe roll, stable IK branches, upright reach-aware balance |
| Manual steering arms | driving.ts: constrained arms and shared steering-wheel grip positions |
| Side/top car and time-driven wheels | Vehicle.tsx: one arc-length route, projected sedan geometry, distance-driven wheels, curvature/Ackermann steering |
| Flat house silhouettes / road | Environment.tsx: architectural elevations, coherent streets, sidewalks, roofs, wet-road/light layers |
| Entry scale animation | DoorSet / doorState: projected physical hinge, handle rotation and exact world-space grip |
| Phone boolean handoff | phoneState: one constant-size prop with continuous position/orientation parenting |
| Old full story audio | audio_preview.py: new brief-compliant English teaser, action-event Foley and stereo ducked mix |
| Remotion + Chromium + FFmpeg | Reused; 1080×1920, 30fps, H.264/AAC |

Full scene upgrades beyond the preview remain subject to approval. See
PRODUCTION.md and output/review.md for implemented versus planned work.

## Build in this workspace

The existing `source/node_modules` symlink uses the retained Remotion 4.0.419
toolchain from Vanta. Python is `/workspace/stick-note-dev/.venv/bin/python`.
ONNX model weights remain in `/workspace/stick-note-dev/models`; not included
in the source ZIP. No extra credentials or external voice API are needed.

```sh
cd /workspace/chase-overhaul
/workspace/stick-note-dev/.venv/bin/python source/audio_preview.py
/workspace/stick-note-dev/tools/node_modules/.bin/esbuild source/motion.ts --platform=node --format=cjs --outfile=output/motion.cjs
/workspace/stick-note-dev/tools/node_modules/.bin/esbuild source/driving.ts --bundle --platform=node --format=cjs --outfile=output/driving.cjs
/workspace/stick-note-dev/tools/node_modules/.bin/esbuild source/Vehicle.tsx --bundle --platform=node --format=cjs --outfile=output/vehicle.cjs
node source/qc.cjs
source/node_modules/.bin/remotion render source/Preview.tsx OverhaulPreview output/preview_picture_final.mp4 --concurrency=3 --browser-executable=/usr/bin/chromium --crf=18 --x264-preset=fast
node source/inspect.mjs
/workspace/stick-note-dev/.venv/bin/python source/finish_preview.py
```

On another machine, install the pinned Remotion/CLI/bundler/renderer 4.0.419,
React 18.3.1, esbuild, FFmpeg and Chromium. Python dependencies: kokoro-onnx
0.6.1, onnxruntime 1.31.1, numpy, soundfile, Pillow. Adapt absolute workspace
and preservation paths before rebuilding. Include baseline preservation records
only when their referenced originals are available; do not silently skip them.

Kokoro model Apache-2.0, kokoro-onnx MIT; Remotion licensing applies separately.
The original and revised procedural artwork, script, Foley and score belong to
this project. No third-party stock sound samples are used. Human listening
approval is outstanding and cannot be replaced with numeric loudness checks.
