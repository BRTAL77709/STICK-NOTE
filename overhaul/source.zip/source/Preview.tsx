import React from 'react';
import {AbsoluteFill,Composition,registerRoot,useCurrentFrame} from 'remotion';
import {Defs,Head,FrontCar,T,L} from './OriginalArt';
import {ExtraDefs,RoadAhead,ArchitecturalHouse,HouseApproach,DoorSet,BedroomSet} from './Environment';
import {Character} from './Character';
import {PerspectiveCar,PerspectiveRoad,routeLength,routeAt} from './Vehicle';
import {doorActor,runActor,phoneActor,phoneState,twoBone,ease,blend,clamp,P} from './motion';
import captions from '../output/preview-captions.json';
import {driverState} from './driving';
const amber='#ffb477',teal='#71ded5';
function Driving({t}:any){const d=driverState(t);return <g>
 <RoadAhead t={t} distance={t*5}/>
 <path d="M0 0 H1080 V350 Q540 210 0 350Z M0 180 L130 1090 L0 1180Z M1080 180 L970 1090 L1080 1190Z" fill="#08131d" stroke="#4b6671" strokeWidth="14"/>
 <path d="M0 1180 Q540 1060 1080 1170 V1920 H0Z" fill="#0b1b29" stroke="#597477" strokeWidth="6"/>
 <path d="M190 1190 Q130 920 305 865 Q452 850 487 1190 L490 1740 H130Z" fill="#14242f" stroke="#45616c" strokeWidth="6"/>
 <g transform={`translate(360 ${1060+d.breath}) scale(1.25)`}>
 <path d="M-46 69 Q0 48 48 70 L66 230 Q0 259 -65 230Z" fill="url(#hood)" stroke="#456c72" strokeWidth="3"/>
 <path d="M-43 74 Q0 124 43 74 L20 59 H-23Z" fill="#0c1822" stroke="#758e84" strokeWidth="2"/>
 <path d="M-25 94 L-12 164 M25 94 L12 164" stroke="#67837d" strokeWidth="2"/>
 <Head t={t+1} look={.2+d.up*.5} up={d.up} fear={d.fear*.7} turn={-d.up*7}/>
 </g>
 {d.arms.map((a,i)=><g key={i}><L p={`${a.a.x},${a.a.y} ${a.joint.x},${a.joint.y} ${a.end.x},${a.end.y}`} w={32.5}/><L p={`${a.a.x+4},${a.a.y-2} ${a.joint.x+4},${a.joint.y-2} ${a.end.x+4},${a.end.y-2}`} w={2.5} c="#507a80"/></g>)}
 <g transform={`rotate(${d.angle*180/Math.PI} 500 1340)`}><circle cx="500" cy="1340" r="155" fill="none" stroke="#030b15" strokeWidth="32"/><circle cx="500" cy="1340" r="155" fill="none" stroke="#67878a" strokeWidth="3"/><path d="M500 1340 L363 1265 M500 1340 L637 1265 M500 1340 V1490" stroke="#273f4b" strokeWidth="21"/><circle cx="500" cy="1340" r="51" fill="#102632" stroke="#527078" strokeWidth="4"/></g>
 {[d.a,d.b].map((p,i)=><g key={i} transform={`translate(${p.x} ${p.y}) rotate(${d.angle*180/Math.PI})`}><ellipse rx={24-d.fear} ry={32+d.fear} fill="url(#skin)"/><path d="M-11 -11 h21 m-22 8 h23 m-22 8 h21" stroke="#799b96" strokeWidth="2.5"/></g>)}
 <path d="M700 280 V350" stroke="#0b1a25" strokeWidth="24"/><rect x="500" y="350" width="515" height="225" rx="28" fill="#0a1420" stroke="#718a90" strokeWidth="9"/>
 <g clipPath="url(#newMirror)"><rect x="520" y="365" width="480" height="195" fill="#2b4852"/><path d="M723 365 H791 L1000 565 H520Z" fill="#142532"/>{[0,1,2,3,4].map(i=><path key={i} d={`M758 ${380+((i*43-t*40)%175+175)%175} v13`} stroke="#a8b8aa" strokeWidth="4"/>)}<FrontCar t={t} x={760+Math.sin(t)*1.5} y={484} s={3.7/d.gap}/><path d="M530 370 L720 370 L540 550Z" fill="#b4d7cd" opacity=".055"/></g>
 <path d="M740 1250 H1010 L1045 1450 H685Z" fill="#172f3b" stroke="#496b72" strokeWidth="3"/>
 {[0,1].map(i=><g key={i}><circle cx={790+i*145} cy="1340" r="49" fill="#091722" stroke="#67928e" strokeWidth="3"/><path d={`M${790+i*145} 1340 l${27*Math.cos(t*.2+i)} ${-27*Math.sin(t*.2+i)}`} stroke={amber} strokeWidth="3"/></g>)}
 <T x={85} y={1715} size={25} fill={teal} letterSpacing="5">02:17 AM</T>
 </g>}
function Turning({t}:any){let u=clamp(t/3),distance=routeLength*(.20+.40*(u+.07*Math.sin(2*Math.PI*u)));return <g>
 <rect width="1080" height="1920" fill="url(#night)"/>
 <ArchitecturalHouse x={160} y={700} s={.8} number="15"/><ArchitecturalHouse x={970} y={700} s={.8} number="17"/>
 <PerspectiveRoad/>
 <PerspectiveCar distance={Math.max(0,distance-6)}/><PerspectiveCar distance={distance} blue/>
 <path d="M0 600 H1080 V820 H0Z" fill="url(#haze)"/>
 </g>}
function Running({t}:any){const p=runActor(t),track=clamp((p.x-200)*.45,0,300);return <g transform={`translate(${-track} 0)`}><HouseApproach t={t}/><Character pose={p}/></g>}
function Door({t}:any){const p=doorActor(t),zoom=1+.26*ease((t-2.8)/2);return <g transform={`translate(${600*(1-zoom)} ${1300*(1-zoom)}) scale(${zoom})`}><DoorSet t={t}/><Character pose={p} contact={t>=3.55}/></g>}
function Phone({t}:any){const p=phoneActor(t),ps=phoneState(t),zoom=1+.10*ease(t/5);let hand=ps.attached?p.rightArm.end:{x:620+Math.sin(t*95)*(t<1.4?1.6:0),y:1440};return <g transform={`translate(${600*(1-zoom)} ${1350*(1-zoom)}) scale(${zoom})`}><BedroomSet t={t}/><Character pose={p} contact={ps.attached}/><g transform={`translate(${hand.x} ${hand.y}) rotate(${ps.angle})`}><rect x="-21" y="-73" width="42" height="78" rx="8" fill="#071321" stroke="#8caaa7" strokeWidth="2.5"/><rect x="-16" y="-66" width="32" height="61" rx="5" fill="#69cbbc"/><path d="M-5 -61 H5" stroke="#143a42" strokeWidth="3"/><path d="M-10 -42 H10 M-10 -34 H7" stroke="#e8f2dd" strokeWidth="2.5"/></g></g>}
export function Preview(){const t=useCurrentFrame()/30;let shot=t<3?<Driving t={t}/>:t<6?<Turning t={t-3}/>:t<9?<Running t={t-6}/>:t<15?<Door t={t-9}/>:<Phone t={t-15}/>;
 const cue=captions.find((c:any)=>t>=c.start&&t<c.end);
 const label=t<3?'MIRROR / DRIVING':t<6?'VEHICLE TURN':t<9?'GROUNDED RUN':t<15?'HANDLE CONTACT / WALK':'PHONE ATTACHMENT';
 return <AbsoluteFill style={{background:'#06111c'}}><svg width="1080" height="1920" viewBox="0 0 1080 1920"><Defs/><ExtraDefs/>{shot}<rect width="1080" height="1920" fill="url(#vig)" pointerEvents="none"/><rect width="1080" height="120" fill="#030a12"/><rect y="1800" width="1080" height="120" fill="#030a12"/><T x={55} y={70} size={21} fill="#b7c9bb" letterSpacing="5">THE PRICE OF SILENCE</T><T x={1010} y={70} size={16} center fill={amber}>PREVIEW</T>{cue&&<g><rect x="75" y="188" width="930" height="112" rx="9" fill="#030c17" opacity=".86"/><T x={540} y={257} size={31} center fontWeight={550}>{cue.text}</T></g>}<path d={`M55 1852 H${55+970*t/20}`} stroke={amber} strokeWidth="3"/><T x={55} y={1895} size={15} fill="#839d95" letterSpacing="3">{label}</T></svg></AbsoluteFill>;
}
registerRoot(()=> <Composition id="OverhaulPreview" component={Preview} durationInFrames={600} fps={30} width={1080} height={1920}/>);
