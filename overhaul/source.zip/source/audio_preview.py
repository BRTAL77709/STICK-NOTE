from pathlib import Path
import json,math,subprocess
import numpy as np,soundfile as sf,onnxruntime as rt
from kokoro_onnx import Kokoro
P=Path(__file__).resolve().parents[1];O=P/'output';S=24000;D=20
opt=rt.SessionOptions();opt.intra_op_num_threads=3
k=Kokoro.from_session(rt.InferenceSession('/workspace/stick-note-dev/models/kokoro-v1.0.onnx',sess_options=opt,providers=['CPUExecutionProvider']),'/workspace/stick-note-dev/models/voices-v1.0.bin')
v=np.zeros((S*D,2),np.float32);fx=np.zeros_like(v);events=[];cues=[]
lines=[(.25,5.9,'At two seventeen, a black car took every turn I did.','am_michael'),(6.15,8.8,"I thought I'd lost it.",'am_michael'),(9.35,12.2,'I just needed to get inside.','am_michael'),(15.15,17.0,'Then my phone lit up.','am_michael'),(17.15,18.4,'Unknown number.','am_michael'),(18.95,19.92,'One million dollars.','am_adam')]
for i,(start,end,text,voice) in enumerate(lines):
 a,sr=k.create(text,voice=voice,speed=.90 if voice=='am_michael' else .86,lang='en-us')
 hit=np.flatnonzero(abs(a)>.008)
 if len(hit):a=a[max(0,hit[0]-700):min(len(a),hit[-1]+1300)]
 if len(a)/S>end-start:
  # Keep pitch with FFmpeg atempo; do not resample the voice into a different pitch.
  sf.write(O/'voice_temp.wav',a,S)
  ratio=(len(a)/S)/(end-start)
  subprocess.run(['ffmpeg','-v','error','-y','-i',str(O/'voice_temp.wav'),'-af',f'atempo={ratio:.8f}',str(O/'voice_timed.wav')],check=True)
  a,_=sf.read(O/'voice_timed.wav');a=a[:int((end-start)*S)]
 a=a*.45/max(.01,float(max(abs(a))))
 if voice=='am_adam':
  a=np.convolve(a,np.ones(7)/7,mode='same')
  a=a-np.convolve(a,np.ones(95)/95,mode='same')
  # One small pre-call pause; controlled telephone filtering, no shouting.
 length=len(a);idx=round(start*S)
 v[idx:idx+length,0]+=a;v[idx:idx+length,1]+=a
 sf.write(O/f'preview_voice_{i}.wav',a,S)
 words=text.split();chunks=[words[j:j+7] for j in range(0,len(words),7)];cursor=start
 for chunk in chunks:
  stop=cursor+length/S*len(chunk)/len(words);cues.append({'start':cursor,'end':stop,'text':' '.join(chunk)});cursor=stop
 print(i,voice,round(length/S,2),text,flush=True)
rng=np.random.default_rng(217)
def add(at,a,name,pan=0):
 at=math.ceil(at*30-1e-7)/30;i=round(at*S);n=min(len(a),len(fx)-i)
 if n<=0:return
 theta=(pan+1)*np.pi/4
 fx[i:i+n,0]+=a[:n]*np.cos(theta);fx[i:i+n,1]+=a[:n]*np.sin(theta)
 events.append({'time':at,'end':at+n/S,'name':name,'pan':pan})
def tone(sec,hz,amp,decay):
 t=np.arange(round(sec*S))/S;return amp*np.sin(2*np.pi*hz*t)*np.exp(-decay*t)
def noise(sec,amp):
 t=np.arange(round(sec*S))/S;n=rng.normal(0,1,len(t));return n*amp*np.sin(np.pi*t/sec)**2
x=np.arange(6*S)/S
rpm=42+8*np.sin(x*.8)+9*np.sin(x*.25);phase=np.cumsum(2*np.pi*rpm/S)
add(0,(.031*np.sin(phase)+.014*np.sin(2*phase))*(1-.45*np.clip((x-5.4)/.6,0,1)),'engine / turn load')
add(0,np.convolve(rng.normal(0,1,6*S),np.ones(90)/90,mode='same')*.025,'wet tire noise')
for at in [3.4,3.95,4.5]:add(at,tone(.13,850,.025,30),'indicator click',-.18)
add(3.45,noise(2.2,.006),'cornering tire scrub',.15)
# Footstep impact times use the exact rendered landing events, not a free-running loop.
for t in [.36,.61,.86,1.11,1.36,1.61,1.86,2.11,2.36]:
 at=6+t*1.2;add(at,tone(.14,88,.105,35)+noise(.14,.022),'run foot plant',-.45+.55*t/2.5)
for t in [.85,1.45,2,2.55,4.42,4.9]:add(9+t,tone(.16,106,.075,30)+noise(.16,.009),'walk foot plant',-.25)
add(12.55,tone(.17,910,.055,26),'hand contacts handle',.2)
add(12.88,tone(.2,620,.085,32),'latch disengages',.2)
q=np.arange(int(1.1*S))/S
add(12.95,.012*np.sin(2*np.pi*(280*q+3*np.sin(q*9)))*np.sin(np.pi*q/1.1)**2,'hinge rotation',.25)
for at in [15.1,15.7,16.3]:
 q=np.arange(int(.33*S))/S
 add(at,.065*np.sin(2*np.pi*112*q)*(np.sin(2*np.pi*23*q)>.15)*np.sin(np.pi*q/.33)**2,'phone surface vibration',.2)
add(16.65,noise(.16,.014),'phone lifts from table',.12)
add(18.77,tone(.15,880,.042,23),'answer click',.05)
for at in [6.4,7.35,8.25,15.8,17.0]:
 n=np.convolve(rng.normal(0,1,round(.45*S)),np.ones(12)/12,mode='same')
 add(at,n*.023*np.sin(np.linspace(0,np.pi,len(n)))**2,'restrained breath')
t=np.arange(S*D)/S
amb=np.convolve(rng.normal(0,1,len(t)),np.ones(170)/170,mode='same')*.018
score=.009*np.sin(2*np.pi*43.65*t+np.sin(t*.15))+.004*np.sin(2*np.pi*65.41*t)
duck=np.ones(len(t))
for c in cues:duck[max(0,int((c['start']-.12)*S)):min(len(t),int((c['end']+.16)*S))]=.35
bed=amb+score*duck
mix=v+fx+bed[:,None]
fade=np.minimum(t/.15,1)*np.clip((D-t)/.12,0,1)
mix=np.tanh(mix*1.3)*.93*fade[:,None]
sf.write(O/'preview_mix.wav',mix,S,subtype='PCM_24')
(O/'preview-captions.json').write_text(json.dumps(cues,indent=2)+'\n')
(O/'preview-sound-events.json').write_text(json.dumps(events,indent=2)+'\n')
def stamp(x):
 m=round(x*1000);return f'00:{m//60000:02}:{m//1000%60:02},{m%1000:03}'
(O/'preview.srt').write_text('\n\n'.join(f"{i+1}\n{stamp(c['start'])} --> {stamp(c['end'])}\n{c['text']}" for i,c in enumerate(cues))+'\n')
print('Preview mix complete; peak',20*np.log10(max(abs(mix.flatten()))),flush=True)
