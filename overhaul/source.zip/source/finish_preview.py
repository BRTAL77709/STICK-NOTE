from pathlib import Path
import subprocess,json,hashlib,zipfile
import numpy as np
from PIL import Image,ImageDraw
P=Path(__file__).resolve().parents[1];O=P/'output'
def run(args):return subprocess.run(args,check=True,capture_output=True,text=True)
def loud(path):
 s=run(['ffmpeg','-hide_banner','-i',str(path),'-af','loudnorm=I=-16:TP=-1.5:LRA=8:print_format=json','-f','null','-']).stderr
 return json.JSONDecoder().raw_decode(s[s.rfind('{'):])[0]
stats=loud(O/'preview_mix.wav')
f='loudnorm=I=-16:TP=-1.5:LRA=8:measured_I='+stats['input_i']+':measured_TP='+stats['input_tp']+':measured_LRA='+stats['input_lra']+':measured_thresh='+stats['input_thresh']+':offset='+stats['target_offset']+':linear=true'
run(['ffmpeg','-v','error','-y','-i',str(O/'preview_mix.wav'),'-af',f,'-ar','48000',str(O/'preview_master.wav')])
movie=O/'overhaul-preview.mp4'
run(['ffmpeg','-v','error','-y','-i',str(O/'preview_picture_final.mp4'),'-i',str(O/'preview_master.wav'),'-i',str(O/'preview.srt'),'-map','0:v','-map','1:a','-map','2:0','-c:v','copy','-c:a','aac','-b:a','192k','-c:s','mov_text','-metadata:s:s:0','language=eng','-metadata','title=THE PRICE OF SILENCE — Overhaul approval preview','-movflags','+faststart','-t','20',str(movie)])
meta=json.loads(run(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(movie)]).stdout)
(O/'ffprobe.json').write_text(json.dumps(meta,indent=2))
video=next(s for s in meta['streams'] if s['codec_type']=='video');audio=next(s for s in meta['streams'] if s['codec_type']=='audio')
assert video['codec_name']=='h264' and (video['width'],video['height'])==(1080,1920)
assert video['r_frame_rate']=='30/1' and int(video['nb_read_frames'])==600
assert audio['codec_name']=='aac' and audio['channels']==2 and abs(float(meta['format']['duration'])-20)<.1
assert not run(['ffmpeg','-v','error','-xerror','-i',str(movie),'-f','null','-']).stderr.strip()
volume=loud(movie);assert float(volume['input_tp'])<0
(O/'loudness.json').write_text(json.dumps(volume,indent=2))
qc=json.loads((O/'kinematics-qc.json').read_text())
times=[.6,1.7,2.6,3.5,4.8,5.6,6.8,7.5,8.6,9.4,10.5,11.5,12.6,13.6,14.5,15.5,16.65,17.6,18.5,19.5]
sheet=Image.new('RGB',(1080,1640),'#08121c');draw=ImageDraw.Draw(sheet)
for i,t in enumerate(times):
 frame=O/f'final_{t}.jpg';run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',str(movie),'-frames:v','1','-vf','scale=216:384',str(frame)])
 x=i%5*216;y=i//5*410;sheet.paste(Image.open(frame),(x,y));draw.text((x+8,y+389),str(t)+'s',fill='white')
sheet.save(O/'preview-contact-sheet.jpg',quality=95)
def frame(t):
 b=subprocess.check_output(['ffmpeg','-v','error','-ss',str(t),'-i',str(movie),'-frames:v','1','-vf','scale=270:480','-f','rawvideo','-pix_fmt','rgb24','-'])
 return np.frombuffer(b,np.uint8).reshape(480,270,3)
spans=[]
for t in [.4,2.6]:
 im=frame(t)[100:140,132:249];mask=(im[:,:,0]>110)&(im[:,:,1]>130)&(im[:,:,2]>110)
 yy,xx=np.where(mask);assert len(xx);spans.append(int(xx.max()-xx.min()+1))
assert spans[1]>spans[0]*1.3
cues=json.loads((O/'preview-captions.json').read_text());assert all(0<=c['start']<c['end']<=20 for c in cues)
assert all(a['end']<=b['start']+.001 for a,b in zip(cues,cues[1:]))
events=json.loads((O/'preview-sound-events.json').read_text())
assert all(abs(e['time']*30-round(e['time']*30))<1e-6 for e in events)
for name,h in json.loads((P/'preserved/original-hashes.json').read_text()).items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==h
manifest={'file':movie.name,'size_bytes':movie.stat().st_size,'sha256':hashlib.sha256(movie.read_bytes()).hexdigest(),'duration_seconds':20,'fps':30,'width':1080,'height':1920,'frames':600,'approval':'pending','mirror_headlight_span_px':spans,'full_film_rendered':False}
(O/'delivery.json').write_text(json.dumps(manifest,indent=2)+'\n')
report=f'''# Overhaul preview — implementation and review status

**Approval pending. No complete revised-film render has been made.**

## Implemented and exercised in this 20-second preview

- 0–3s: same original stickman Head artwork, upward mirror glance, fear/tension,
  breathing, articulated driving arms, hands constrained to rotating wheel rim.
- 3–6s: both cars follow one arc-length street path with a 6m rear-axle gap.
  Corner speed decreases near the apex and increases on exit; front steering
  follows curvature with inner/outer Ackermann angles. Wheel rotation follows
  per-wheel travel/radius, including different inside/outside travel.
  Suspension moves the body while tire bottoms remain on the road plane.
- 6–9s: acceleration, grounded alternating run, counter-swinging arms,
  forward lean, braking/settling and a follow camera toward number 17.
- 9–15s: upright walking with planted support feet and heel/toe roll, reach,
  grip, handle turn and hinge-projected door opening. The hand follows the
  SAME transformed point used to draw the handle. This preview ends with the
  door open; complete entry/closing/locking is not represented as finished.
- 15–20s: new room/furniture depth, phone vibration, continuous pickup of one
  constant-size phone prop, screen-reading pause, tremor and near-ear movement.
  The carried phone and hand share a single world-space attachment.
- Architectural houses with roofs, side walls, windows, porch details, curbs,
  wet-road reflections, streetlight pools, haze, subtle trees/curtains and
  purposeful camera tracking/push-ins. Original minimalist character identity
  and source body dimensions are retained; environments may change under the
  expanded request.

## Actual checks

Full FFmpeg decoding with -xerror passed. MP4 H.264/AAC, fast-start,
1080×1920, 30fps, 600 video frames, 20 seconds; English burned-in captions and
selectable mov_text subtitle track. {len(cues)} caption cues validated for range
and overlap. Audio: {volume['input_i']} LUFS integrated, {volume['input_tp']} dBTP.
Stereo Foley/ambience, centered dialogue, music ducking. {len(events)} sound
events/intervals quantized to rendered frames; footstep impacts follow the
actual foot landing schedule. Headlight span in the rendered fixed mirror shot
grows from {spans[0]} to {spans[1]} pixels at the same downsample scale.

At 120Hz kinematic sampling, every exercised limb stays within reach and has
its original fixed segment lengths. Planted support contact and hand-to-prop
errors are within floating-point rounding; floor penetration is zero. The
checks also bound inter-sample joint jumps, catching the elbow-branch pops
found in an earlier draft. See kinematics-qc.json for measured values.

An early draft had crouched default stances and branch-switching elbows. The
current version uses reach-aware upright body height and explicit stable bend
sides; it was rendered again after these corrections. Representative frames
were inspected and a contact sheet was extracted from the actual muxed MP4.
These are mathematical/technical checks and visual frame review, not a claim
that every aesthetic aspect is professionally approved.

## Still pending / limitations

- Your review of the actual movement, environment quality, pacing and voices.
- This session cannot listen to audio. The narrator/caller are locally generated
  Kokoro voices (am_michael/am_adam), not human-recorded performances. Naturalness
  and subjective mix balance require your listening review.
- The screenplay/shot plan is rewritten, but the full revised conversation,
  curtain/recoil, complete entry/locking, headlights-on threat, sunrise message
  and final vote have not been rendered. The preview is a selected-action reel.
- This is deliberately illustrated 2D / projected vehicle geometry, not a
  photorealistic vehicle or ray-traced lighting simulation.
- Subtitles use phrase timing tied to generated speech, not forced word alignment.

## Preservation

Original source, prior films and original audio hashes were checked unchanged.
The original Head artwork is byte-identical. Work is in a separate project.
Read PRODUCTION.md for the causal rewrite, complete screenplay and shot plan.
Wait for user approval before full-film integration/rendering.
'''
(O/'review.md').write_text(report)
sourceFiles=[p for p in (P/'source').iterdir() if p.is_file() and not p.is_symlink()]
sourceFiles += [P/'PRODUCTION.md',P/'README.md',P/'preserved/original-hashes.json']
sourceFiles += [O/n for n in ['captions.json','preview-captions.json','preview-sound-events.json','preview.srt','preview_mix.wav','kinematics-qc.json','review.md','delivery.json']]
with zipfile.ZipFile(O/'overhaul-source.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in sourceFiles:z.write(f,f.relative_to(P))
print(json.dumps(manifest,indent=2),flush=True)
