import {bundle} from '@remotion/bundler';
import {openBrowser,selectComposition,renderStill} from '@remotion/renderer';
const root='/workspace/chase-overhaul';
const url=await bundle({entryPoint:root+'/source/Preview.tsx'});
const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium'});
try{
 const composition=await selectComposition({serveUrl:url,id:'OverhaulPreview',puppeteerInstance:browser});
 for (const t of [.8,2,4.6,6.8,8.6,10.2,11.4,12.5,13,14,15.3,16.65,17.5,18.6,19.5]){
  await renderStill({serveUrl:url,composition,puppeteerInstance:browser,frame:Math.round(t*30),imageFormat:'jpeg',scale:.5,output:root+`/output/inspect_${t}.jpg`});console.log(t);
 }
}finally{await browser.close({silent:true});}
