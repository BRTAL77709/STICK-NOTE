// Geometry is in world pixels. Feet and prop contacts are solved before camera transforms.
export type P={x:number,y:number};
export const add=(a:P,b:P):P=>({x:a.x+b.x,y:a.y+b.y});
export const sub=(a:P,b:P):P=>({x:a.x-b.x,y:a.y-b.y});
export const mul=(a:P,s:number):P=>({x:a.x*s,y:a.y*s});
export const len=(a:P)=>Math.hypot(a.x,a.y);
export const clamp=(x:number,a=0,b=1)=>Math.max(a,Math.min(b,x));
export const ease=(x:number)=>{x=clamp(x);return x*x*x*(10+x*(-15+6*x))};
export const blend=(a:number,b:number,t:number)=>a+(b-a)*t;
export const point=(a:P,b:P,t:number):P=>({x:blend(a.x,b.x,t),y:blend(a.y,b.y,t)});
export const rotate=(p:P,a:number):P=>({x:p.x*Math.cos(a)-p.y*Math.sin(a),y:p.x*Math.sin(a)+p.y*Math.cos(a)});
export function twoBone(a:P,target:P,L1:number,L2:number,pole:P,bend?:number){
 const d=sub(target,a),raw=len(d),r=clamp(raw,Math.abs(L1-L2)+.001,L1+L2-.001);
 const end=add(a,mul(d,r/Math.max(raw,.00001)));
 const theta=Math.atan2(d.y,d.x),offset=Math.acos(clamp((L1*L1+r*r-L2*L2)/(2*L1*r),-1,1));
 const p1=add(a,{x:Math.cos(theta+offset)*L1,y:Math.sin(theta+offset)*L1});
 const p2=add(a,{x:Math.cos(theta-offset)*L1,y:Math.sin(theta-offset)*L1});
 const joint=bend===undefined?(len(sub(p1,pole))<len(sub(p2,pole))?p1:p2):(bend>0?p1:p2);
 return {a,joint,end,target,error:len(sub(end,target)),upper:len(sub(joint,a)),lower:len(sub(end,joint))};
}
export type Step={start:number,end:number,to:number,lift?:number};
export type Foot={heel:P,toe:P,ankle:P,planted:boolean,contact:P|null,phase:string};
export function footTrack(t:number,startX:number,steps:Step[],ground:number,s:number):Foot{
 let previous=startX,lastEnd=-99,next:Step|undefined;
 const base=ground-11.5*s,roll=.18;
 for(const step of steps){
  if(t<step.start){next=step;break;}
  if(t>=step.end){previous=step.to;lastEnd=step.end;continue;}
  const q=clamp((t-step.start)/(step.end-step.start)),w=ease(q);
  const from={x:previous+36*s*(1-Math.cos(roll)),y:base-36*s*Math.sin(roll)};
  const heel={x:blend(from.x,step.to,w),y:blend(from.y,base,w)-Math.sin(Math.PI*q)**1.25*(step.lift||38)*s};
  const pitch=blend(roll,-.12,w)-.25*Math.sin(Math.PI*q);
  const toe=add(heel,rotate({x:36*s,y:0},pitch));
  return {heel,toe,ankle:heel,planted:false,contact:null,phase:'swing'};
 }
 const landing=ease((t-lastEnd)/.10);
 let pitch=lastEnd>0?blend(-.12,0,landing):0;
 let heel={x:previous,y:base},contact={x:previous,y:ground},phase=landing<1?'heel-to-toe':'stance';
 if(next&&t>next.start-.10){
  pitch=roll*ease((t-next.start+.10)/.10);
  heel={x:previous+36*s*(1-Math.cos(pitch)),y:base-36*s*Math.sin(pitch)};
  contact={x:previous+36*s,y:ground};phase='toe-off';
 }
 const toe=add(heel,rotate({x:36*s,y:0},pitch));
 return {heel,toe,ankle:heel,planted:true,contact,phase};
}
export type ActorInput={t:number,x:number,ground:number,s:number,left:Foot,right:Foot,lean?:number,head?:number,look?:number,up?:number,fear?:number,leftHand?:P,rightHand?:P,handAngle?:number,run?:boolean};
export function actorPose(i:ActorInput){
 const {t,x,s,ground}=i;
 const supportL=1-ease((ground-11.5*s-i.left.heel.y)/(12*s)),supportR=1-ease((ground-11.5*s-i.right.heel.y)/(12*s));
 const flight=(1-supportL)*(1-supportR),weight=supportL-supportR;
 const breath=Math.sin(t*(i.fear?4.5:2.1))*(i.fear?1.5:.7)*s;
 const rootX=x+weight*.8*s;
 const desired=ground-420*s+breath-flight*4*s;
 const limit=(foot:Foot,side:number)=>{
  const dx=foot.ankle.x-(rootX+side*27*s),maxReach=174.8*s;
  return foot.ankle.y-Math.sqrt(Math.max(.001,maxReach*maxReach-dx*dx))-237*s;
 };
 const smoothMax=(a:number,b:number)=>Math.max(a,b)+Math.log1p(Math.exp(-Math.abs(a-b)/(.75*s)))*(.75*s);
 const root={x:rootX,y:smoothMax(smoothMax(desired,limit(i.left,-1)),limit(i.right,1))};
 const lean=(i.lean||0)*Math.PI/180;
 const body=(p:P)=>add(root,mul(add(rotate(sub(p,{x:0,y:237}),lean),{x:0,y:237}),s));
 const hipL=add(root,{x:-27*s,y:237*s}),hipR=add(root,{x:27*s,y:237*s});
 const leftLeg=twoBone(hipL,i.left.ankle,90*s,86*s,add(hipL,{x:110*s,y:30*s}),-1);
 const rightLeg=twoBone(hipR,i.right.ankle,90*s,86*s,add(hipR,{x:110*s,y:30*s}),-1);
 const swing=clamp((i.left.heel.x-i.right.heel.x)/(160*s),-1,1);
 const lh=i.leftHand||body({x:-70-swing*(i.run?65:30),y:i.run?185+swing*25:290-Math.abs(swing)*12});
 const rh=i.rightHand||body({x:70+swing*(i.run?65:30),y:i.run?185-swing*25:290-Math.abs(swing)*12});
 const shoulderL=body({x:-44,y:92}),shoulderR=body({x:44,y:92});
 const leftArm=twoBone(shoulderL,lh,110*s,115*s,body({x:-150,y:190}),-1);
 const rightArm=twoBone(shoulderR,rh,110*s,115*s,body({x:150,y:190}),1);
 return {...i,root,body,lean,leftLeg,rightLeg,leftArm,rightArm};
}
export const walkSteps={
 left:[{start:.35,end:.85,to:315},{start:1.5,end:2,to:415},{start:4.05,end:4.42,to:375,lift:22}],
 right:[{start:.95,end:1.45,to:365},{start:2,end:2.55,to:485},{start:4.45,end:4.9,to:435,lift:22}],
};
export function doorState(t:number){
 const turn=ease((t-3.55)/.35),open=ease((t-3.95)/1.05);
 const theta=open*1.22,handle=-turn*.38;
 const local={x:40+40*Math.cos(handle),y:790+40*Math.sin(handle)};
 const grip={x:600+Math.cos(theta)*local.x,y:480+local.y+Math.sin(theta)*local.x*.16};
 const gripAngle=Math.atan2(Math.sin(handle)+Math.sin(theta)*.16*Math.cos(handle),Math.cos(theta)*Math.cos(handle));
 return {theta,handle,grip,open,turn,gripAngle};
}
export function doorActor(t:number){
 const s=.85,ground=1580;
 const ds=doorState(t);
 const x=230+240*ease(t/3)-34*ds.open;
 let hand:P|undefined;
 const rest={x:x+70*s,y:ground-386*s+230*s};
 if(t>=3.0)hand=point(rest,ds.grip,ease((t-3)/.55));
 const input:ActorInput={t,x,ground,s,left:footTrack(t,215,walkSteps.left,ground,s),right:footTrack(t,255,walkSteps.right,ground,s),lean:1.2*Math.sin(Math.PI*clamp(t/3))-2*ds.open,look:.8,up:.15,fear:.3,head:blend(0,-5,ds.open),rightHand:hand,handAngle:ds.gripAngle};
 return actorPose(input);
}
const runLeft:Step[]=[{start:.05,end:.36,to:220,lift:65},{start:.55,end:.86,to:400,lift:65},{start:1.05,end:1.36,to:580,lift:65},{start:1.55,end:1.86,to:760,lift:65},{start:2.05,end:2.36,to:900,lift:50}];
const runRight:Step[]=[{start:.30,end:.61,to:310,lift:65},{start:.80,end:1.11,to:490,lift:65},{start:1.30,end:1.61,to:670,lift:65},{start:1.80,end:2.11,to:850,lift:60}];
function integralEase(u:number){u=clamp(u);return 2.5*u**4-3*u**5+u**6;}
export function runDistance(t:number){
 t=clamp(t,0,2.5);
 let acc=t<.25?.25*integralEase(t/.25):t-.125;
 if(t>2.05)acc-=.45*integralEase((t-2.05)/.45);
 return 360*acc;
}
export function runActor(time:number){
 const t=clamp(time/1.2,0,2.5),s=.8,ground=1680;
 const speed=ease(t/.25)*(1-ease((t-2.05)/.45));
 return actorPose({t,x:80+runDistance(t),ground,s,left:footTrack(t,40,runLeft,ground,s),right:footTrack(t,130,runRight,ground,s),lean:7*speed-2*Math.sin(Math.PI*ease((t-2.05)/.45)),fear:.85,look:1,head:-3*Math.sin(t*1.5),run:true});
}
export function phoneState(t:number){
 const lift=ease((t-1.65)/1.05),answer=ease((t-3.25)/.7),tremble=t>2.6?Math.sin(t*37)*.7:0;
 const grip=point({x:620,y:1440},{x:548+tremble,y:1315},lift);
 const wrist=point(grip,{x:510+tremble,y:1240},answer);
 const angle=blend(82,-12,lift)+answer*18;
 return {lift,answer,wrist,angle,attached:t>=1.65};
}
export function phoneActor(t:number){
 const s=.85,ground=1570,x=470;
 const ps=phoneState(t),rest={x:510,y:1437};
 const hand=point(rest,ps.wrist,ease((t-.45)/1.15));
 return actorPose({t,x,ground,s,left:footTrack(t,427,[],ground,s),right:footTrack(t,476,[],ground,s),lean:2.5*ease((t-.45)/1.15)*(1-ps.lift)-1.8*ps.answer,head:blend(6,-4,ps.answer),look:1,up:-.3+ps.answer*.3,fear:.65,rightHand:hand,handAngle:ps.angle*Math.PI/180});
}
