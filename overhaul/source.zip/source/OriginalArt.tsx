import React from 'react';
import {AbsoluteFill,Composition,registerRoot,useCurrentFrame} from 'remotion';
import captions from '../output/captions.json';
const W=1080,H=1920,FPS=30,D=102;
const teal='#71ded5',amber='#ffb477',white='#e9eee1',black='#081219';
const cl=(x:number)=>Math.max(0,Math.min(1,x));
const sm=(x:number)=>{x=cl(x);return x*x*(3-2*x)};
const mix=(a:number,b:number,x:number)=>a+(b-a)*x;
const T=({x,y,size=34,fill=white,children,center=false,...props}:any)=><text x={x} y={y} fill={fill} fontSize={size} textAnchor={center?'middle':'start'} fontFamily="DejaVu Sans,sans-serif" {...props}>{children}</text>;
const L=({p,w=25,c=black,...props}:any)=><polyline points={p} fill="none" stroke={c} strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" {...props}/>;
const Defs=()=> <defs>
 <linearGradient id="night" x2="0" y2="1"><stop stopColor="#0a1726"/><stop offset=".65" stopColor="#22414b"/><stop offset="1" stopColor="#06121c"/></linearGradient>
 <linearGradient id="skin" x2="1" y2="1"><stop stopColor="#ffffe9"/><stop offset="1" stopColor="#7cb5b3"/></linearGradient>
 <linearGradient id="hood" x2="1" y2="1"><stop stopColor="#283d46"/><stop offset="1" stopColor="#070f1b"/></linearGradient>
 <linearGradient id="car" x2="0" y2="1"><stop stopColor="#34454e"/><stop offset=".45" stopColor="#080e18"/><stop offset=".8" stopColor="#15242f"/><stop offset="1" stopColor="#030812"/></linearGradient>
 <linearGradient id="bluecar" x2="0" y2="1"><stop stopColor="#537c88"/><stop offset=".6" stopColor="#1d424e"/><stop offset="1" stopColor="#071a26"/></linearGradient>
 <linearGradient id="room" x2="1" y2="1"><stop stopColor="#233f46"/><stop offset="1" stopColor="#07111e"/></linearGradient>
 <radialGradient id="light"><stop stopColor="#ffca91" stopOpacity=".4"/><stop offset="1" stopColor="#ffc27b" stopOpacity="0"/></radialGradient>
 <radialGradient id="glow"><stop stopColor={teal} stopOpacity=".3"/><stop offset="1" stopColor={teal} stopOpacity="0"/></radialGradient>
 <radialGradient id="vig"><stop offset=".4" stopColor="#01040b" stopOpacity="0"/><stop offset="1" stopColor="#01040b" stopOpacity=".55"/></radialGradient>
 <clipPath id="mirrorclip"><rect x="525" y="367" width="470" height="192" rx="24"/></clipPath>
 <clipPath id="wind"><path d="M52 430 Q540 220 1025 430 L1000 1110 H80Z"/></clipPath>
 </defs>;

function Head({t,x=0,y=0,scale=1,look=0,up=0,fear=0,turn=0,criminal=false}:any){
 const blink=t%4.13<.13?.06:1;
 return <g transform={`translate(${x} ${y}) scale(${scale}) rotate(${turn})`}>
 <path d="M-74 9 Q-88 -91 0 -96 Q90 -91 76 29 L53 62 H-48Z" fill="#09151d" stroke="#55777b" strokeWidth="4"/>
 <ellipse rx="61" ry="66" fill={criminal?'#809792':'url(#skin)'} stroke="#0a1824" strokeWidth="5"/>
 <path d="M-63 -22 Q-70 -89 1 -85 Q69 -82 66 -24Z" fill="#101b28" stroke="#5f7d80" strokeWidth="3"/>
 <path d="M-65 -22 Q8 -43 88 -12 L95 0 H-64Z" fill="#182c38" stroke="#67817e" strokeWidth="3"/>
 <ellipse cx={-20+look*12} cy={11-up*12} rx={5+fear*2} ry={(8+fear*5)*blink} fill="#051420"/>
 <ellipse cx={23+look*12} cy={11-up*12} rx={5+fear*2} ry={(8+fear*5)*blink} fill="#051420"/>
 <path d={`M-33 ${-4-fear*10} L-12 ${-5-fear*10} M15 ${-5-fear*10} L36 ${-4-fear*10}`} stroke="#16303a" strokeWidth="4"/>
 {criminal?<path d="M-51 21 Q0 10 53 21 L35 58 H-36Z" fill="#0a1722"/>:<ellipse cx="7" cy="39" rx={8-fear*4} ry={2+fear*5} fill="#35565d"/>}
 </g>
}

function Rig({t,x,y,scale=1,mode='idle',phase=0,look=0,fear=0,left,right,turn=0,criminal=false,phone=false}:any){
 const gait=mode==='run'?Math.sin(t*12+phase):mode==='walk'?Math.sin(t*7+phase):0;
 const bob=mode==='run'?-Math.abs(gait)*12:mode==='walk'?-Math.abs(gait)*6:Math.sin(t*(fear?4.5:2.2))*2.5;
 const lean=mode==='run'?14:mode==='walk'?5:0;
 const leftHand=left||[-70-gait*62,mode==='run'?155-gait*40:230];
 const rightHand=right||[70+gait*62,mode==='run'?155+gait*40:230];
 const limb=(sx:number,sy:number,ex:number,ey:number,bend:number)=>{
  const dx=ex-sx,dy=ey-sy,dist=Math.max(5,Math.min(224.5,Math.hypot(dx,dy))),angle=Math.atan2(dy,dx)+(sx<0?1:dx>=0&&dy<80?1:-1)*Math.acos(Math.max(-1,Math.min(1,(110*110+dist*dist-115*115)/(220*dist)))); const mx=sx+Math.cos(angle)*110,my=sy+Math.sin(angle)*110;
  return <g><L p={`${sx},${sy} ${mx},${my} ${ex},${ey}`} w={26}/><L p={`${sx+5},${sy} ${mx+5},${my} ${ex+5},${ey}`} w={2} c="#507a80"/><circle cx={ex} cy={ey} r="13" fill="url(#skin)"/></g>;
 };
 return <g transform={`translate(${x} ${y+bob}) scale(${scale}) rotate(${lean})`}>
 <ellipse cx="15" cy="414" rx="135" ry="16" fill="#01070d" opacity=".7"/>
 {[-1,1].map(side=>{let a=gait*side*(mode==='run'?.95:.55),b=a-Math.max(0,gait*side)*(mode==='run'?1.8:.95)+.08;let hx=side*27,kx=hx+Math.sin(a)*90,ky=237+Math.cos(a)*90,fx=kx+Math.sin(b)*86,fy=ky+Math.cos(b)*86;return <g key={side}>
 <L p={`${hx},237 ${kx},${ky} ${fx},${fy}`} w={28}/>
 <L p={`${fx},${fy} ${fx+36},${fy+3}`} w={23} c="#030b14"/>
 </g>})}
 <path d="M-46 69 Q0 48 48 70 L66 230 Q0 259 -65 230Z" fill="url(#hood)" stroke="#456c72" strokeWidth="3"/>
 <path d="M-43 74 Q0 124 43 74 L20 59 H-23Z" fill="#0c1822" stroke="#758e84" strokeWidth="2"/>
 <path d="M-25 94 L-12 164 M25 94 L12 164 M-35 192 Q0 176 35 192 L30 217 H-30Z" fill="none" stroke="#67837d" strokeWidth="2"/>
 {limb(-44,92,leftHand[0],leftHand[1],-38)}
 {limb(44,92,rightHand[0],rightHand[1],35)}
 {phone&&<g transform={`translate(${rightHand[0]} ${rightHand[1]-24}) rotate(-12)`}><rect x="-17" y="-34" width="34" height="58" rx="6" fill="#061321" stroke={teal} strokeWidth="2"/><rect x="-11" y="-27" width="22" height="40" fill={teal}/></g>}
 <Head t={t} look={look} fear={fear} turn={turn} criminal={criminal}/>
 </g>
}

function FrontCar({t,x,y,s=1,lights=true}:any){return <g transform={`translate(${x} ${y}) scale(${s})`}>
 <ellipse cy="93" rx="210" ry="35" fill="#000" opacity=".65"/>
 {lights&&<><path d="M-164 43 L-330 420 H-40 L-124 43Z" fill="#c4f4dc" opacity=".09"/><path d="M124 43 L40 420 H330 L164 43Z" fill="#c4f4dc" opacity=".09"/></>}
 <rect x="-192" y="28" width="46" height="89" rx="13" fill="#02060b"/><rect x="146" y="28" width="46" height="89" rx="13" fill="#02060b"/>
 <path d="M-181 62 L-183 -1 L-124 -110 Q0 -144 124 -110 L183 -1 L181 62Z" fill="url(#car)" stroke="#69828a" strokeWidth="4"/>
 <path d="M-123 -95 Q0 -117 123 -95 L151 -21 H-151Z" fill="#163642" stroke="#46717e" strokeWidth="3"/>
 <path d="M-110 -88 L-30 -101 L-63 -29 H-141Z" fill="#90cfc6" opacity=".1"/>
 <path d="M-169 11 Q0 -8 169 11 L157 53 H-157Z" fill="#0d1c27"/>
 <path d="M-162 20 H-100 M100 20 H162" stroke={lights?'#d3f7e5':'#4d6770'} strokeWidth="13"/>
 <path d="M-70 39 H70 M-60 48 H60" stroke="#638185" strokeWidth="4"/><rect x="-40" y="56" width="80" height="16" fill="#59676c"/>
 </g>}

function SideCar({t,x,y,scale=1,blue=false,rotation=0,door=0,moving=true,occupant=true,lights=true}:any){
 const wheel=t*(moving?700:0);
 return <g transform={`translate(${x} ${y}) scale(${scale}) rotate(${rotation})`}>
 <ellipse cx="0" cy="85" rx="330" ry="35" fill="#01060c"/>
 <path d="M-302 35 L-284 -20 L-153 -40 L-78 -128 Q52 -149 171 -107 L236 -39 L303 -12 L315 42 L286 76 H-286Z" fill={blue?'url(#bluecar)':'url(#car)'} stroke="#78969a" strokeWidth="4"/>
 <path d="M-124 -48 L-58 -113 Q45 -128 145 -95 L198 -45Z" fill="#142e3b" stroke="#577a87" strokeWidth="3"/>
 <path d="M-27 -117 V-44" stroke="#8a9e9e" strokeWidth="5"/>
 {occupant&&<g transform="translate(88 -64) scale(.32)"><Head t={t} criminal={!blue}/></g>}
 <path d="M-264 -12 Q0 7 277 -14 M-90 50 H182" stroke="#8bb7b6" opacity=".5" strokeWidth="3" fill="none"/>
 <path d="M-255 22 L-92 16 M26 15 L265 23" stroke="#d2ece0" opacity=".1" strokeWidth="8"/>
 <rect x="-280" y="12" width="23" height="19" fill="#ff725d"/><rect x="283" y="6" width="23" height="18" fill={lights?"#cfe8cd":"#3c515d"}/>
 {[-194,203].map(cx=><g key={cx} transform={`translate(${cx} 70) rotate(${wheel})`}><circle r="54" fill="#02060b" stroke="#263a46" strokeWidth="6"/><circle r="31" fill="#64747a"/>{[0,60,120].map(a=><path key={a} d="M-25 0 H25" stroke="#1a2c36" strokeWidth="8" transform={`rotate(${a})`}/>)}</g>)}
 {door>0&&<g transform={`translate(18 -37) scale(${1-door*.65} 1) skewY(${door*-24})`}><path d="M0 -5 L163 -5 L180 88 H0Z" fill={blue?'#426b79':'#182b38'} stroke="#9bb7b4" strokeWidth="4"/><path d="M8 -9 L8 -75 L106 -72 L156 -9Z" fill="#16303d" stroke="#739295" strokeWidth="3"/><path d="M122 20 h30" stroke="#d0d5bd" strokeWidth="7"/></g>}
 </g>
}

function Road({t,speed=1}:any){return <g>
 <rect width={W} height={H} fill="url(#night)"/><circle cx="835" cy="385" r="47" fill="#b8d9d2" opacity=".5"/>
 {[0,1,2,3,4,5].map(i=><path key={i} d={`M${i*210-90} 800 v-${100+i%3*90} h130 v${100+i%3*90}Z`} fill="#0b1b29"/>)}
 <path d="M450 760 H630 L1220 1920 H-140Z" fill="#111e2a"/>
 <path d="M442 760 L-100 1920 M638 760 L1180 1920" stroke="#779492" strokeWidth="9"/>
 {[0,1,2,3,4,5,6,7].map(i=>{let p=((i/8+t*speed*.18)%1);let q=p*p;let y=760+q*1160;return <path key={i} d={`M${540-2-q*10} ${y} l${-q*6} ${25+q*130} h${5+q*20} l${-q*6} ${-25-q*130}Z`} fill="#d6d6b4" opacity={.1+.7*p}/>})}
 {[-1,1].map(side=>[0,1,2,3].map(i=>{let p=((i/4+t*speed*.09)%1),q=p*p;let x=540+side*(110+q*820),y=760+q*1100;return <g key={side+'-'+i} opacity={cl(p*4)}><path d={`M${x} ${y} V${y-140-q*560} l${-side*(40+q*80)} -20`} stroke="#37535a" strokeWidth={3+q*9}/><ellipse cx={x-side*(40+q*80)} cy={y-160-q*560} rx={20+q*140} ry={40+q*220} fill="url(#light)"/><path d={`M${x-side*(30+q*70)} ${y-160-q*560} h${-side*(25+q*35)}`} stroke={amber} strokeWidth={3+q*9}/></g>}))}
 </g>}

function Mirror({t,p,large=false}:any){
 const s=mix(.22,1.05,sm(p));
 return <g transform={large?'translate(-1010 -100) scale(2.04)':''}>
 <path d="M744 280 V363" stroke="#101c28" strokeWidth="22"/>
 <rect x="511" y="352" width="498" height="222" rx="32" fill="#050c17" stroke="#6a8289" strokeWidth="9"/>
 <g clipPath="url(#mirrorclip)">
 <rect x="525" y="367" width="470" height="192" fill="#2b4852"/>
 <path d="M730 380 H790 L997 565 H524Z" fill="#142532"/>
 {[0,1,2,3].map(i=>{let y=390+((i*45+t*95)%175);return <path key={i} d={`M757 ${y} v15`} stroke="#a6b9ad" strokeWidth="4"/>})}
 <g transform="translate(760 480)"><FrontCar t={t} x={Math.sin(t*1.8)*5} y={0} s={s}/></g>
 <path d="M540 382 L780 382 L560 545Z" fill="#d0f1e2" opacity=".045"/>
 </g>
 </g>
}

function Interior({t,u,fright=true,corner=false}:any){
 const fear=sm((u-4.5)/1),up=sm((u-1.5)/1)*(1-sm((u-6)/.6));
 const angle=corner?Math.sin(u*.6)*65:Math.sin(t*.8)*12;
 const rad=angle*Math.PI/180;
 const grip=(a:number)=>[620+Math.cos(a+rad)*178,1300+Math.sin(a+rad)*178];
 const a=grip(-2.55),b=grip(-.59);
 return <g>
 <Road t={t} speed={u>7?2.4:1}/>
 <path d="M0 0 H1080 V380 Q540 250 0 380Z M0 220 L120 1050 L0 1180Z M1080 220 L970 1070 L1080 1190Z" fill="#060e18" stroke="#455d66" strokeWidth="14"/>
 <path d="M0 1120 Q540 985 1080 1120 V1920 H0Z" fill="#0b1b29" stroke="#597477" strokeWidth="6"/>
 <path d="M580 1120 H960 L1010 1290 H530Z" fill="#142d37" stroke="#496970" strokeWidth="4"/>
 {[0,1,2].map(i=><g key={i}><circle cx={620+i*125} cy="1195" r="46" fill="#091722" stroke="#608a88" strokeWidth="3"/><path d="M0 0 L29 -18" transform={`translate(${620+i*125} 1195) rotate(${u>7?40:0})`} stroke={amber} strokeWidth="3"/></g>)}
 <path d="M130 1090 Q80 830 245 802 Q414 790 448 1110 L465 1770 H80Z" fill="#14242f" stroke="#45616c" strokeWidth="6"/>
 <g transform={`translate(300 ${1010+Math.sin(t*(fear?7:2))*(fear?8:3)})`}>
 <path d="M-65 65 Q0 40 80 75 L110 325 H-77Z" fill="url(#hood)" stroke="#56787b" strokeWidth="4"/>
 <path d="M-43 80 L-15 154 M38 79 L19 156" stroke="#8b9e8e" strokeWidth="3"/>
 <Head t={t} scale={1.2} look={u<1.5?-sm(u/.7):.25} up={up} fear={fear} turn={u<1.5?-12*sm(u/.7):-up*7}/>
 <path d="M-55 130 L100 240" stroke="#95a9a1" strokeWidth="12"/>
 </g>
 <L p={`250,1112 340,1230 ${a[0]},${a[1]}`} w={47}/>
 <L p={`378,1112 425,1190 ${b[0]},${b[1]}`} w={47}/>
 <L p={`258,1110 348,1220 ${a[0]+4},${a[1]-5}`} w={3} c="#649b9b"/>
 <g transform={`rotate(${angle} 620 1300)`}><circle cx="620" cy="1300" r="178" fill="none" stroke="#030b15" strokeWidth="35"/><circle cx="620" cy="1300" r="178" fill="none" stroke="#67878a" strokeWidth="3"/><path d="M620 1300 L467 1215 M620 1300 L773 1215 M620 1300 V1478" stroke="#273f4b" strokeWidth="22"/><circle cx="620" cy="1300" r="57" fill="#102632" stroke="#527078" strokeWidth="4"/></g>
 {[a,b].map((p,i)=><g key={i}><ellipse cx={p[0]} cy={p[1]} rx="26" ry="35" fill="url(#skin)" transform={`rotate(${angle} ${p[0]} ${p[1]})`}/><path d={`M${p[0]-10} ${p[1]-12} h20 m-22 10 h24`} stroke="#799b96" strokeWidth="3"/></g>)}
 <Mirror t={t} p={u/8}/>
 <T x={66} y={1680} size={24} fill={teal}>MIDNIGHT · COUNTY ROAD 9</T>
 </g>
}

function Pedal({t,u}:any){let push=sm(u/1.1);return <g>
 <rect width={W} height={H} fill="#101f2b"/>
 <path d="M80 400 H1000 L920 1650 H80Z" fill="#07111c" stroke="#48636b" strokeWidth="9"/>
 {[0,1,2,3,4,5,6].map(i=><path key={i} d={`M120 ${900+i*90} H950`} stroke="#1c303e" strokeWidth="12"/>)}
 <path d="M770 650 v300" stroke="#4e6870" strokeWidth="35"/>
 <g transform={`rotate(${push*23} 770 650)`}><rect x="690" y="900" width="140" height="260" rx="20" fill="#4d646a" stroke="#90aaa5" strokeWidth="5"/>{[0,1,2,3].map(i=><path key={i} d={`M710 ${935+i*54} H810`} stroke="#1c3039" strokeWidth="15"/>)}</g>
 <path d={`M280 1920 L${385+push*115} ${1360-push*160} L${555+push*95} ${1180-push*90}`} stroke="#142a37" strokeWidth="165" strokeLinecap="round" fill="none"/>
 <g transform={`translate(${555+push*95} ${1180-push*90}) rotate(${-35+push*25})`}><path d="M-60 20 Q-83 -52 -20 -66 L117 -56 Q166 -42 148 13 L-50 45Z" fill="#07101b" stroke="#6d9191" strokeWidth="6"/><path d="M-45 37 H130" stroke="#b3c1b0" strokeWidth="8"/></g>
 <T x={100} y={460} size={28} fill={amber} letterSpacing="7">NO MORE SLOWING DOWN</T>
 </g>}

function Roadside({t,u}:any){return <g>
 <rect width={W} height={H} fill="url(#night)"/>
 <rect y="980" width="1080" height="940" fill="#0b1925"/>
 <path d="M0 1390 H1080 M0 1670 H1080" stroke="#5e7678" strokeWidth="7"/>
 <rect x="50" y="440" width="870" height="560" fill="#162833" stroke="#536465" strokeWidth="5"/>
 <path d="M30 440 L430 280 L950 440Z" fill="#0a1824"/>
 <rect x="110" y="620" width="250" height="370" fill="#27363b"/><rect x="535" y="590" width="270" height="220" fill="#091821" stroke="#506764" strokeWidth="5"/>
 <T x={450} y={520} center size={22} fill="#82938b" letterSpacing="7">CLOSED AFTER DARK</T>
 <rect x="367" y="905" width="130" height="95" fill="#665847"/><rect x="395" y="842" width="100" height="60" fill="#7b6a52"/>
 {[0,1].map(i=>{let enter=sm((u-2.5-i*.6)/2.4);let x=mix(380+i*180,725+i*30,enter),y=880;return enter<.98&&<Rig key={i} t={t} x={x} y={y+enter*250} scale={.62*(1-enter*.5)} criminal mode={enter>0?'walk':'idle'} look={-1} turn={-18*sm((u-.8)/.7)} right={u<2?[95,150]:undefined}/>})}
 <SideCar t={t} x={720} y={1220} scale={.9} door={u>2&&u<5.5?Math.sin(cl((u-2)/3.5)*Math.PI):0} moving={false}/>
 <path d="M0 1800 H1080" stroke="#c4c3a8" strokeWidth="8" strokeDasharray="110 90"/>
 </g>}

function TopCar({x,y,rotation,blue=false}:any){return <g transform={`translate(${x} ${y}) rotate(${rotation})`}>
 <ellipse cy="10" rx="72" ry="162" fill="#000" opacity=".6"/>
 {[-1,1].map(side=>[-95,90].map(yy=><rect key={side+'-'+yy} x={side<0?-69:54} y={yy} width="15" height="49" rx="4" fill="#02070d"/>))}
 <path d="M-58 115 L-61 -118 Q-57 -155 0 -158 Q57 -155 61 -118 L58 115 Q55 145 0 149 Q-55 145 -58 115Z" fill={blue?'url(#bluecar)':'url(#car)'} stroke="#8eaaa8" strokeWidth="3"/>
 <path d="M-45 -73 L45 -73 L40 -27 H-40Z" fill="#254955" stroke="#6c969b" strokeWidth="3"/>
 <path d="M-40 -22 H40 L43 68 H-43Z" fill={blue?'#284b59':'#101e2c'} stroke="#5c7d84" strokeWidth="2"/>
 <path d="M-42 72 H42 L45 103 H-45Z" fill="#274652" stroke="#668c91" strokeWidth="2"/>
 <path d="M-42 -134 H-20 M20 -134 H42" stroke="#d7f2db" strokeWidth="7"/>
 <path d="M-42 129 H-21 M21 129 H42" stroke="#e98375" strokeWidth="6"/>
 <path d="M-40 -73 L-5 -73 L-30 -28 H-40Z" fill="#8ed0c9" opacity=".16"/>
 </g>}
function Exterior({t,u,turn=false}:any){
 let a=sm(u/5.5),b=sm((u-1)/5.5);
 return <g><rect width={W} height={H} fill="url(#night)"/>
 {[0,1,2,3,4].map(i=><path key={i} d={`M${i*250-70} 800 v-${150+i%2*130} h170 v${150+i%2*130}`} fill="#0a1a27"/>)}
 {turn?<><path d="M-200 1750 Q650 1780 610 1000 Q580 760 1250 760" fill="none" stroke="#1a2b37" strokeWidth="330"/><path d="M-200 1750 Q650 1780 610 1000 Q580 760 1250 760" fill="none" stroke="#a9b5a5" strokeWidth="6" strokeDasharray="65 70"/>
 {[a,b].map((p,i)=>{let q=p<.6?p/.6:(p-.6)/.4;let A=p<.6?[-200,1750]:[610,1000],B=p<.6?[650,1780]:[580,760],C=p<.6?[610,1000]:[1250,760];let x=(1-q)*(1-q)*A[0]+2*(1-q)*q*B[0]+q*q*C[0],y=(1-q)*(1-q)*A[1]+2*(1-q)*q*B[1]+q*q*C[1],dx=2*(1-q)*(B[0]-A[0])+2*q*(C[0]-B[0]),dy=2*(1-q)*(B[1]-A[1])+2*q*(C[1]-B[1]),angle=Math.atan2(dy,dx)*180/Math.PI+90;return <TopCar key={i} x={x} y={y} rotation={angle} blue={!i}/>})}</>:<>
 <path d="M-200 1080 L1300 1350 V1920 H-200Z" fill="#1c2c37"/>
 {[0,1,2,3,4,5].map(i=><path key={i} d={`M${((i*300-t*620)%1800)-300} 1500 l160 30`} stroke="#b7c1ae" strokeWidth="8"/>)}
 <SideCar t={t*1.7} x={730+Math.sin(t)*30} y={1310} scale={.85} blue/>
 <SideCar t={t*1.7} x={-90+u*65} y={1550} scale={.85}/>
 </>}
 <T x={65} y={470} size={27} fill={amber} letterSpacing="5">{turn?'ONE TURN. STILL BEHIND ME.':'THEY WERE GETTING CLOSER.'}</T>
 </g>
}

function House({t}:any){return <g>
 <rect width={W} height={H} fill="url(#night)"/>
 <path d="M70 780 L560 320 L1035 780Z" fill="#0a1724" stroke="#516b72" strokeWidth="8"/>
 <rect x="130" y="775" width="845" height="680" fill="#243b43" stroke="#506c70" strokeWidth="6"/>
 {[250,740].map(x=><g key={x}><rect x={x} y="840" width="150" height="230" fill="#091b2b" stroke="#6b8b89" strokeWidth="8"/><path d={`M${x+75} 840 v230 M${x} 950 h150`} stroke="#506c70" strokeWidth="6"/></g>)}
 <rect x="468" y="1120" width="200" height="330" fill="#1b2930" stroke="#90927a" strokeWidth="8"/>
 <circle cx="626" cy="1300" r="10" fill={amber}/>
 <ellipse cx="700" cy="1200" rx="200" ry="300" fill="url(#light)"/><path d="M695 1110 v45" stroke={amber} strokeWidth="14"/>
 <path d="M400 1455 H730 L830 1920 H270Z" fill="#3b4c50"/>
 <rect y="1665" width="1080" height="255" fill="#101e2a"/>
 <path d="M405 1455 H735 L800 1660 H338Z" fill="#43565a"/>
 </g>}

function Escape({t,u}:any){
 if(u<6){let park=sm(u/1.8),open=sm((u-1.8)/.7)*(1-sm((u-4.7)/.6)),exit=sm((u-2.5)/2.2);return <g><House t={t}/>
 <SideCar t={t} x={mix(-450,500,park)} y={1610} scale={1.05} blue door={open} moving={u<1.8} occupant={u<3.3}/>{u>1.3&&u<2.9&&<g><L p={`600,1555 ${mix(610,645,sm((u-1.3)/.7))},${mix(1560,1590,sm((u-1.3)/.7))}`} w={15}/><circle cx={mix(610,645,sm((u-1.3)/.7))} cy={mix(1560,1590,sm((u-1.3)/.7))} r="10" fill="url(#skin)"/></g>}
 {u>2.5&&<Rig t={t} x={mix(600,840,exit)} y={mix(1430,1320,exit)} scale={.55+exit*.33} mode={u>4.5?'run':'walk'} fear={1} right={u<4.5?[-50,110]:undefined}/>}
 </g>}
 let run=sm((u-6)/6);return <g><House t={t}/><SideCar t={t} x={210} y={1740} scale={.9} blue moving={false} occupant={false}/><Rig t={t} x={mix(840,567,run)} y={mix(1320,1210,run)} scale={mix(.88,.58,run)} mode={u<11.6?'run':'idle'} fear={1}/></g>
}

function EntryInside({t,u}:any){let close=sm((u-3.3)/.7),lock=sm((u-4.1)/.7),leave=sm(u-5);return <g>
 <rect width={W} height={H} fill="#243e45"/>
 <path d="M0 1510 H1080 V1920 H0Z" fill="#132733"/><path d="M0 1510 H1080 M0 1680 H1080" stroke="#496269" strokeWidth="4"/>
 <rect x="105" y="500" width="270" height="570" fill="#19303a" stroke="#6b8380" strokeWidth="7"/>
 <path d="M140 620 H340 M180 620 V660 M290 620 V660 M140 690 Q180 640 220 690 L240 1000 H120Z M250 690 Q290 640 330 690 L350 1000 H230Z" fill="#0b1d2a" stroke="#42616a" strokeWidth="5"/>
 <rect x="570" y="400" width="360" height="1130" fill="#030b14" stroke="#839990" strokeWidth="12"/>
 <path d="M585 1150 H915 V1520 H585Z" fill="#102636"/>
 <g transform={`translate(580 415) scale(${.16+.84*close} 1)`}>
 <rect width="340" height="1100" fill="#3b514f" stroke="#98a18b" strokeWidth="5"/><path d="M30 40 H310 V490 H30Z M30 560 H310 V1050 H30Z" fill="none" stroke="#6a8179" strokeWidth="5"/>
 <rect x="30" y="800" width="35" height="95" rx="10" fill="#8d9d8b"/><path d="M45 845 h65" stroke={amber} strokeWidth="8"/>
 </g>
 <Rig t={t} x={480+leave*600} y={1170} scale={.85} mode={u>5?'run':'idle'} fear={1} look={u>5?1:.5} right={u>5?undefined:[120+close*50,130]}/>
 {u>=4&&u<5&&<g transform={`rotate(${lock*90} 621 1280)`}><path d="M604 1280 H638" stroke={amber} strokeWidth="8"/><path d="M616 1268 v22" stroke="#e0e7cf" strokeWidth="6"/></g>}
 <T x={70} y={330} size={25} fill={amber} letterSpacing="6">INSIDE · TURN THE LOCK</T>
 </g>}
function Entry({t,u}:any){
 if(u>=3.2)return <EntryInside t={t} u={u}/>;
 const unlock=sm(u/.9),open=sm((u-1)/.7),enter=sm((u-1.9)/1.5),close=sm((u-3.3)/.7),lock=sm((u-4.1)/.7);
 return <g><rect width={W} height={H} fill="url(#room)"/><path d="M0 1500 H1080 V1920 H0Z" fill="#172733"/>
 <rect x="480" y="360" width="470" height="1190" fill="#020b14" stroke="#8b9b8b" strokeWidth="14"/>
 {open>0&&close<1&&<g transform={`translate(0 ${20*enter})`}><path d="M500 600 H920 V1510 H500Z" fill="#152939"/><path d="M510 1500 L900 1500 L800 1100 H620Z" fill="#30484e"/></g>}
 <g transform={`translate(490 380) scale(${1-open*.84+close*open*.84} 1)`}><rect width="440" height="1150" fill="#334647" stroke="#929982" strokeWidth="5"/><path d="M30 40 H400 V520 H30Z M30 590 H400 V1090 H30Z" fill="none" stroke="#607572" strokeWidth="6"/><rect x="35" y="850" width="35" height="80" rx="10" fill="#8f9a88"/><path d="M50 875 h70" stroke={amber} strokeWidth="9"/><circle cx="51" cy="912" r="8" fill="#12212d"/></g>
 <Rig t={t} x={mix(390,600,enter)-close*180+sm((u-5)/1)*550} y={1170} scale={.85} mode={enter>0&&enter<1?'walk':u>5?'run':'idle'} fear={1} look={1} right={u>5?undefined:u<1?[160,142]:u>4?[170,130]:[115,130]}/>
 {u<1&&<g transform={`translate(526 1290) rotate(${unlock*85})`}><circle r="12" fill="none" stroke="#b6c9ae" strokeWidth="6"/><path d="M0 0 H48 m-12 0 v12" stroke={amber} strokeWidth="7"/></g>}
 {u>4&&<path d="M555 1280 h30" stroke={amber} strokeWidth="8" transform={`rotate(${lock*90} 570 1280)`}/>}
 <T x={70} y={420} size={26} fill={amber} letterSpacing="5">HOME DIDN'T FEEL SAFE.</T>
 </g>
}

function Stairs({t,u}:any){let p=cl(u/5);return <g>
 <rect width={W} height={H} fill="url(#room)"/>
 <path d="M0 1720 L1080 640 V1920 H0Z" fill="#0a1724"/>
 {[0,1,2,3,4,5,6,7,8].map(i=><path key={i} d={`M${i*135} ${1720-i*135} h135 v135`} fill="none" stroke="#6a8381" strokeWidth="9"/>)}
 <path d="M0 1230 L1080 150" stroke="#a2b2a1" strokeWidth="16"/>
 {[0,1,2,3,4].map(i=><path key={i} d={`M${i*250} ${1230-i*250} v490`} stroke="#536f73" strokeWidth="8"/>)}
 <Rig t={t} x={mix(60,1010,p)} y={mix(1350,400,p)} scale={.75} mode="run" fear={1}/>
 </g>}

function Bedroom({t,curtain=0}:any){return <g>
 <rect width={W} height={H} fill="url(#room)"/><path d="M0 1480 L1080 1390 V1920 H0Z" fill="#112532"/>
 <rect x="80" y="440" width="150" height="1000" fill="#030b13" stroke="#647c7b" strokeWidth="7"/><g transform={`translate(80 440) scale(${1-.84*sm((t-60.8)/.8)} 1)`}><rect width="150" height="1000" fill="#1e333e" stroke="#7f9691" strokeWidth="5"/><circle cx="120" cy="670" r="8" fill={amber}/></g>
 <rect x="560" y="390" width="430" height="650" fill="#071322" stroke="#849b92" strokeWidth="14"/>
 <path d="M775 390 V1040 M560 730 H990" stroke="#49666e" strokeWidth="10"/>
 <path d={`M530 350 H${775-curtain*150} Q${730-curtain*190} 700 ${785-curtain*170} 1130 H530Z`} fill="#28494d" stroke="#678480" strokeWidth="5"/>
 <path d={`M1018 350 H${780+curtain*170} Q${815+curtain*170} 700 ${780+curtain*170} 1130 H1020Z`} fill="#28494d" stroke="#678480" strokeWidth="5"/>
 <path d="M540 340 H1025" stroke="#8ca79a" strokeWidth="12"/>
 <g transform="translate(-100 180)"><path d="M75 1360 Q250 1270 485 1370 L570 1770 H55Z" fill="#35545a" stroke="#7a9189" strokeWidth="7"/>
 <path d="M72 1370 Q250 1320 470 1400 L480 1470 L65 1460Z" fill="#79918b"/>
 </g><path d="M550 1460 H755 L780 1680 H535Z" fill="#3b4240" stroke="#7e8f7e" strokeWidth="4"/>
 <ellipse cx="655" cy="1370" rx="190" ry="300" fill="url(#light)"/>
 <path d="M660 1450 V1280" stroke="#8f8a6c" strokeWidth="8"/><path d="M620 1210 H700 L722 1290 H600Z" fill={amber}/>
 </g>}

function WindowScene({t,u}:any){let walk=sm(u/2),lift=sm((u-1.4)/.8),pull=sm((u-2.2)/1.4);return <g><Bedroom t={t} curtain={pull}/><Rig t={t} x={mix(200,770,walk)} y={1075} scale={.9} mode={walk<1?'walk':'idle'} fear={1} look={1} right={[mix(70,5,lift)+pull*195,mix(230,-25,lift)]}/></g>}

function OutsidePOV({t,u}:any){return <g>
 <rect width={W} height={H} fill="url(#night)"/>
 <rect x="0" y="360" width="1080" height="480" fill="#243840"/>
 {[70,390,760].map(x=><g key={x}><path d={`M${x-70} 460 l190 -150 l190 150Z`} fill="#111f2d"/><rect x={x} y="460" width="240" height="340" fill="#21343d"/><rect x={x+40} y="530" width="65" height="90" fill="#0b1c2a"/></g>)}
 <path d="M0 880 H1080 V1480 H0Z" fill="#182b39"/><path d="M0 1150 H1080" stroke="#bdc4ac" strokeWidth="8" strokeDasharray="120 100"/>
 <SideCar t={t} x={540} y={900} scale={1.3} moving={false} occupant={false} lights={false}/>
 <path d="M0 70 V1840 M1080 70 V1840 M0 1670 H1080 M790 0 V1920" stroke="#0b1926" strokeWidth="60"/>
 <path d="M20 1700 L760 0" stroke="#93c1b7" strokeWidth="60" opacity=".03"/>
 <T x={500} y={1430} center size={28} fill={amber} letterSpacing="5">HEADLIGHTS OFF. ENGINE COLD.</T>
 </g>}

function PhoneInsert({t}:any){let shake=Math.sin(t*110)*3;return <g>
 <rect width={W} height={H} fill="#1a2a31"/>
 {[0,1,2,3,4,5].map(i=><path key={i} d={`M${i*230-150} 0 L${i*230+100} 1920`} stroke="#61706a" strokeWidth="4" opacity=".35"/>)}
 <ellipse cx="540" cy="1000" rx="430" ry="690" fill="url(#glow)"/>
 <g transform={`translate(${shake} ${Math.sin(t*90)*2}) rotate(-4 540 990)`}>
 <rect x="280" y="420" width="520" height="1100" rx="65" fill="#040c15" stroke="#7ca3a5" strokeWidth="7"/>
 <rect x="300" y="442" width="480" height="1054" rx="48" fill="#193946"/>
 <rect x="445" y="460" width="190" height="28" rx="14" fill="#030b13"/>
 <T x={540} y={640} center size={23} fill={teal} letterSpacing="6">INCOMING CALL</T>
 <T x={540} y={785} center size={44} fontWeight={700}>UNKNOWN</T><T x={540} y={845} center size={44} fontWeight={700}>NUMBER</T>
 <circle cx="540" cy="1130" r="65" fill="#75c4a5"/>
 <path d="M510 1120 Q540 1155 570 1120" stroke="#0a2630" strokeWidth="13" fill="none"/>
 <T x={540} y={1280} center size={24} fill="#a4c6bb">slide to answer</T>
 </g></g>}
function PhoneScene({t,u}:any){
 const retreat=sm(u/3),reach=sm((u-6)/2),lift=sm((u-8)/1.8),answer=sm((u-11)/1.7);
 let hx=mix(70,175,reach)-lift*80-answer*30,hy=mix(230,260,reach)-lift*200-answer*30;
 return <g><Bedroom t={t} curtain={1}/>
 <Rig t={t} x={mix(770,450,retreat)} y={mix(1075,1200,sm((u-2.6)/.9))} scale={.9} mode={u<3.5?'walk':'idle'} phase={Math.PI} fear={1} look={u<3?1:.2} right={[hx,hy]} phone={u>=8}/>
 {u<8&&<g transform={`translate(${620+Math.sin(t*90)*(u>4?2:0)} 1440) rotate(82)`}><rect x="-29" y="-60" width="58" height="100" rx="10" fill="#081722" stroke={teal} strokeWidth="3"/><rect x="-22" y="-50" width="44" height="80" rx="5" fill={u>4?'#72e4cf':'#152732'}/></g>}
 {u>=4&&u<11&&<g><rect x="85" y="350" width="840" height="230" rx="22" fill="#091b29" stroke={teal} strokeWidth="3"/><T x={505} y={425} center size={22} fill={teal} letterSpacing="6">INCOMING CALL</T><T x={505} y={502} center size={48}>UNKNOWN NUMBER</T></g>}
 {u>=17.4&&<g><rect x="70" y="370" width="940" height="290" rx="20" fill="#10212c" stroke={amber} strokeWidth="3"/><T x={540} y={445} center size={23} fill={amber} letterSpacing="5">THE VOICE ON THE LINE</T><T x={540} y={550} center size={90} fontWeight={800}>$1,000,000</T><T x={540} y={610} center size={32}>“Forget what you saw.”</T></g>}
 </g>
}

function Vote({t}:any){return <g><rect width={W} height={H} fill="#07111c"/><FrontCar t={t} x={540} y={560} s={1.7} lights={false}/><T x={540} y={350} center size={28} fill={amber} letterSpacing="8">THE PRICE OF SILENCE</T><T x={540} y={880} center size={62} fontWeight={800}>WHAT WOULD YOU DO?</T><rect x="80" y="1030" width="920" height="180" rx="8" fill={white}/><T x={540} y={1140} center size={66} fill="#0b1824" fontWeight={800}>TAKE THE MONEY</T><rect x="80" y="1270" width="920" height="180" rx="8" fill={amber}/><T x={540} y={1380} center size={66} fill="#0b1824" fontWeight={800}>CALL THE POLICE</T><T x={540} y={1580} center size={28} letterSpacing="5">COMMENT YOUR CHOICE</T><T x={540} y={1650} center size={25} fill="#9cb6ac">The majority decides Part Two.</T></g>}

function TestScene({t}:any){
 if(t<3)return <Interior t={t+14} u={t+1}/>;
 if(t<5)return <g><Road t={t} speed={1.8}/><Mirror t={t} p={(t-3)/2} large/></g>;
 if(t<7)return <g transform="translate(-130 -700) scale(1.55)"><Interior t={t+14} u={t}/></g>;
 return <Pedal t={t} u={t-7}/>;
}
function Shot({t,proof=false}:any){
 if(proof)return <TestScene t={t}/>;
 if(t<8)return <Interior t={t} u={t<5?-2:t-5}/>;
 if(t<14)return <Roadside t={t} u={t-8}/>;
 if(t<24)return <TestScene t={t-14}/>;
 if(t<30)return <Exterior t={t} u={t-24}/>;
 if(t<32)return <Interior t={t} u={t-30} corner/>;
 if(t<38)return <Exterior t={t} u={t-32} turn/>;
 if(t<50)return <Escape t={t} u={t-38}/>;
 if(t<56)return <Entry t={t} u={t-50}/>;
 if(t<61)return <Stairs t={t} u={t-56}/>;
 if(t<66)return <WindowScene t={t} u={t-61}/>;
 if(t<71)return <OutsidePOV t={t} u={t-66}/>;
 if(t>=76&&t<78)return <PhoneInsert t={t}/>;
 if(t<94)return <PhoneScene t={t} u={t-71}/>;
 return <Vote t={t}/>;
}
function Film({proof=false}:any){let t=useCurrentFrame()/FPS;let sub=captions.find((c:any)=>t>=c.start&&t<c.end);return <AbsoluteFill style={{background:'#030b15'}}><svg width={W} height={H} viewBox={`0 0 ${W} ${H}`}><Defs/><Shot t={t} proof={proof}/><rect width={W} height={H} fill="url(#vig)" pointerEvents="none"/><rect width={W} height="120" fill="#030a12"/><rect y="1800" width={W} height="120" fill="#030a12"/><T x={55} y={70} size={20} fill="#b7c9bb" letterSpacing="6">THE PRICE OF SILENCE</T><T x={1020} y={70} size={18} fill={amber} center>{proof?'TEST':'PART 01'}</T>{!proof&&sub&&t<94&&<g><rect x="60" y="1640" width="960" height="125" rx="10" fill="#020a13" opacity=".91"/><T x={540} y={1713} center size={36} fontWeight={600}>{sub.text}</T></g>}<path d={`M55 1855 H${55+970*cl(t/(proof?10:D))}`} stroke={amber} strokeWidth="3"/><T x={55} y={1895} size={15} fill="#6d8985" letterSpacing="4">AN ORIGINAL ANIMATED HORROR STORY</T></svg></AbsoluteFill>}

export {Defs,Head,SideCar,FrontCar,Mirror,Road,T,L};
