import React from 'react';
import {SideCar,T} from './OriginalArt';
import {doorState,clamp,ease,blend} from './motion';
const amber='#ffb477',teal='#71ded5';
export function ExtraDefs(){return <defs>
 <linearGradient id="wet" x2="0" y2="1"><stop stopColor="#203842"/><stop offset=".45" stopColor="#10212f"/><stop offset="1" stopColor="#081520"/></linearGradient>
 <linearGradient id="haze" x2="0" y2="1"><stop stopColor="#a4c9c1" stopOpacity=".13"/><stop offset="1" stopColor="#a4c9c1" stopOpacity="0"/></linearGradient>
 <linearGradient id="glassNew" x2="1" y2="1"><stop stopColor="#9ed7cf" stopOpacity=".24"/><stop offset=".4" stopColor="#142b39" stopOpacity=".05"/><stop offset="1" stopColor="#8fb6b4" stopOpacity=".18"/></linearGradient>
 <linearGradient id="headBeam" x2="1" y2="0"><stop stopColor="#e3e8bb" stopOpacity=".27"/><stop offset="1" stopColor="#c3e5cb" stopOpacity="0"/></linearGradient>
 <linearGradient id="doorFace" x2="1" y2="0"><stop stopColor="#294147"/><stop offset=".7" stopColor="#3b514f"/><stop offset="1" stopColor="#1b3038"/></linearGradient>
 <radialGradient id="amberPool"><stop stopColor="#e5b17f" stopOpacity=".17"/><stop offset="1" stopColor="#e5b17f" stopOpacity="0"/></radialGradient>
 <pattern id="brick" width="110" height="54" patternUnits="userSpaceOnUse"><path d="M0 0 H110 M0 27 H110 M55 0 V27 M0 27 V54 M110 27 V54" stroke="#6b8585" opacity=".12" fill="none" strokeWidth="2"/></pattern>
 <pattern id="floorboard" width="150" height="400" patternUnits="userSpaceOnUse"><path d="M0 0 V400 M150 0 V400 M0 195 H150" stroke="#6b8585" opacity=".16" fill="none" strokeWidth="3"/></pattern>
 <clipPath id="newMirror"><path d="M520 365 H1000 V560 H520Z"/></clipPath>
 </defs>}
export function ArchitecturalHouse({x,y,s=1,number='17',lit=true}:any){return <g transform={`translate(${x} ${y}) scale(${s})`}>
 <path d="M-320 0 L-305 -340 L0 -525 L305 -340 L320 0Z" fill="#142b37" stroke="#556f77" strokeWidth="5"/>
 <path d="M310 0 L405 -70 L390 -380 L305 -340Z" fill="#102330" stroke="#405963" strokeWidth="4"/>
 <path d="M-350 -340 L0 -555 L350 -340 L320 -318 L0 -502 L-320 -318Z" fill="#0b1a28" stroke="#66818a" strokeWidth="6"/>
 <path d="M0 -555 L98 -592 L423 -399 L350 -340Z" fill="#192e39" stroke="#506e78" strokeWidth="4"/>
 <path d="M-297 -308 H298 V0 H-297Z" fill="#29434a"/><path d="M-297 -308 H298 V0 H-297Z" fill="url(#brick)"/>
 <path d="M-320 0 H340 L388 26 H-350Z" fill="#647778"/>
 {[-205,160].map((xx,i)=><g key={xx}><rect x={xx-60} y="-260" width="120" height="155" fill={lit&&i===1?'#5e665a':'#102b3b'} stroke="#829a96" strokeWidth="7"/><rect x={xx-51} y="-251" width="102" height="137" fill="url(#glassNew)"/><path d={`M${xx} -257 V-108 M${xx-57} -183 H${xx+57}`} stroke="#54727b" strokeWidth="6"/><path d={`M${xx-72} -101 H${xx+72}`} stroke="#91a29a" strokeWidth="7"/></g>)}
 <path d="M-95 0 V-290 H95 V0Z" fill="#1b3038" stroke="#718b89" strokeWidth="7"/>
 <path d="M-77 -272 H77 V-134 H-77Z M-77 -112 H77 V-16 H-77Z" fill="none" stroke="#4b6b70" strokeWidth="4"/>
 <path d="M-115 -300 L0 -345 L115 -300" fill="#132a35" stroke="#91a19a" strokeWidth="5"/>
 <path d="M-110 0 H115 L135 26 H-130Z M-130 26 H135 L153 50 H-146Z" fill="#50666c" stroke="#718580" strokeWidth="3"/>
 <rect x="127" y="-219" width="18" height="38" rx="4" fill={amber}/><ellipse cx="136" cy="-150" rx="120" ry="180" fill="url(#amberPool)"/>
 <T x={0} y={-361} center size={24} fill="#a4b8ad" letterSpacing="5">{number}</T>
 <path d="M-245 -40 Q-280 -140 -305 -47 M225 -42 Q260 -130 282 -52" fill="#1c3d41" stroke="#42666a" strokeWidth="5"/>
 </g>}
function Tree({x,y,s=1,t=0}:any){return <g transform={`translate(${x} ${y}) scale(${s}) rotate(${Math.sin(t*.7+x)*.6})`}>
 <path d="M0 0 Q-7 -110 9 -240 M5 -165 L-43 -211 M7 -126 L44 -182" stroke="#263d43" strokeWidth="15" fill="none"/>
 <path d="M-105 -225 Q-95 -321 -22 -319 Q22 -390 83 -306 Q151 -291 114 -211 Q123 -158 43 -158 Q-70 -144 -105 -225Z" fill="#112c36" stroke="#2c4d54" strokeWidth="4"/>
 </g>}
export function TrackingStreet({t,travel}:any){return <g>
 <rect width="1080" height="1920" fill="url(#night)"/>
 <circle cx="875" cy="385" r="42" fill="#b9d1ca" opacity=".42"/>
 {[0,1,2,3].map(i=><g key={i} transform={`translate(${((i*580-travel*.30)%2400)-350} 790)`}><ArchitecturalHouse x={0} y={0} s={.65} number={21+i*2} lit={i%2===0}/></g>)}
 <path d="M0 1000 L1080 1045 V1195 L0 1150Z" fill="#233d44"/>
 <path d="M0 1120 L1080 1165 V1250 L0 1205Z" fill="#647473"/><path d="M0 1205 L1080 1250 V1280 L0 1235Z" fill="#334b56"/>
 <path d="M0 1235 L1080 1280 V1920 H0Z" fill="url(#wet)"/>
 {Array.from({length:9},(_,i)=>{let x=((i*230-travel)%2100)-400;return <path key={i} d={`M${x} 1670 l110 5`} stroke="#bbbea5" strokeWidth="7" opacity=".7"/>})}
 {Array.from({length:6},(_,i)=>{let x=((i*410-travel*.75)%2500)-500;return <g key={i}><Tree x={x+130} y={1130} s={.85} t={t}/><path d={`M${x} 1200 V665 Q${x} 635 ${x+70} 635`} stroke="#425c66" strokeWidth="11" fill="none"/><path d={`M${x+50} 638 h50`} stroke={amber} strokeWidth="9"/><ellipse cx={x+75} cy="1060" rx="220" ry="390" fill="url(#amberPool)"/><path d={`M${x+75} 1280 l-70 440 h155 l-55 -440Z`} fill={amber} opacity=".055"/></g>})}
 <path d="M0 680 H1080 V980 H0Z" fill="url(#haze)"/>
 </g>}
export function RoadAhead({t,distance=0}:any){return <g>
 <rect width="1080" height="1920" fill="url(#night)"/>
 <path d="M465 650 H615 L1190 1920 H-110Z" fill="url(#wet)"/>
 <path d="M440 650 L-180 1920 M640 650 L1260 1920" stroke="#687f7c" strokeWidth="14"/>
 {[-1,1].map(side=>Array.from({length:5},(_,i)=>{let z=9+i*9-(distance%9);let k=800/z;let x=540+side*7*k,y=650+2*k;return <g key={side+'-'+i}><ArchitecturalHouse x={x} y={y} s={k/180} number={side<0?17+i*2:18+i*2} lit={i%3===0}/><Tree x={x+side*k} y={y+15} s={k/200} t={t}/></g>}))}
 {Array.from({length:13},(_,i)=>{let z=2+i*4-(distance%4),k=800/Math.max(1,z),y=650+2*k;return <path key={i} d={`M${540-k*.025} ${y} v${k*.25}`} stroke="#c4c6aa" strokeWidth={Math.max(2,k*.018)}/>})}
 {[-1,1].map(side=>Array.from({length:6},(_,i)=>{let z=6+i*8-(distance%8),k=800/Math.max(z,1),x=540+side*3.6*k,y=650+2*k;return <g key={side+'-'+i}><path d={`M${x} ${y} v${-4.5*k} l${-side*.7*k} ${-.2*k}`} stroke="#45606a" strokeWidth={Math.max(2,k*.045)}/><ellipse cx={x-side*.7*k} cy={y-4.7*k} rx={k*1.2} ry={k*2.1} fill="url(#amberPool)"/><path d={`M${x-side*.45*k} ${y-4.7*k} h${-side*.5*k}`} stroke={amber} strokeWidth={k*.045}/><ellipse cx={x} cy={y+k*.4} rx={k*1.1} ry={k*.9} fill="url(#amberPool)"/></g>}))}
 <rect x="0" y="550" width="1080" height="240" fill="url(#haze)"/>
 </g>}
export function PolishedCar({t,x,y,s=1,distance=0,blue=false}:any){
 const wheelTime=distance/54*180/Math.PI/700;
 const heave=Math.sin(distance/150)*1.2;
 return <g transform={`translate(${x} ${y}) scale(${s})`}>
 <ellipse cy="105" rx="360" ry="32" fill="#020913" opacity=".8"/>
 <path d="M290 10 L850 -50 V140 L290 45Z" fill="url(#headBeam)"/>
 <g transform={`translate(0 ${heave})`}>
 <SideCar t={wheelTime} x={0} y={0} blue={blue}/>
 <path d="M-122 -48 L-58 -113 Q45 -128 145 -95 L198 -45Z" fill="url(#glassNew)"/>
 <path d={`M${-100+Math.sin(t*.6)*20} -72 l40 -34 M55 -47 l42 -58`} stroke="#a1cac2" strokeWidth="5" opacity=".15"/>
 <path d="M-276 49 H-242 M253 46 H287" stroke="#779e9e" strokeWidth="5"/>
 <path d="M-20 2 h31 M135 1 h28" stroke="#a0b4aa" strokeWidth="5"/>
 </g>
 <path d="M-275 122 Q0 145 300 120" fill="none" stroke={blue?'#4e8795':'#526f7b'} strokeWidth="8" opacity=".1"/>
 </g>
}
export function HouseApproach({t}:any){return <g>
 <rect width="2200" height="1920" fill="url(#night)"/>
 <ArchitecturalHouse x={950} y={1360} s={1.18}/>
 <Tree x={90} y={1410} s={1.5} t={t}/><Tree x={1020} y={1420} s={1.4} t={t}/>
 <path d="M845 1420 H1085 L1345 1920 H545Z" fill="#3b535b" stroke="#738683" strokeWidth="5"/>
 <path d="M0 1600 H2200 V1680 H0Z" fill="#5a6c70"/><path d="M0 1680 H2200 V1920 H0Z" fill="url(#wet)"/>
 <path d="M845 1420 L705 1680 M1085 1420 L1225 1680" stroke="#94a193" strokeWidth="4"/>
 <ellipse cx="960" cy="1550" rx="290" ry="290" fill="url(#amberPool)"/>
 </g>}
export function DoorSet({t}:any){const ds=doorState(t);return <g>
 <rect width="1080" height="1920" fill="url(#room)"/><path d="M0 1580 H1080 V1920 H0Z" fill="#203640"/>
 <rect width="1080" height="1580" fill="url(#brick)"/>
 <path d="M0 1580 H1080 M0 1780 H1080" stroke="#647c7c" strokeWidth="6"/>
 <rect x="575" y="445" width="455" height="1145" fill="#0b1723" stroke="#79918d" strokeWidth="13"/>
 <path d="M600 480 H980 V1580 H600Z" fill="#122936"/>
 <path d="M600 1580 L980 1580 L940 1450 H655Z" fill="#a4b694" opacity={ds.open*.11}/>
 <g transform={`translate(600 480) matrix(${Math.cos(ds.theta)} ${Math.sin(ds.theta)*.16} 0 1 0 0)`}>
 <rect x="0" y="0" width="380" height="1100" fill="url(#doorFace)" stroke="#96a28e" strokeWidth="5"/>
 <path d="M30 45 H350 V500 H30Z M30 565 H350 V1055 H30Z" fill="none" stroke="#668079" strokeWidth="6"/>
 <rect x="25" y="755" width="31" height="94" rx="10" fill="#7f9587"/>
 <g transform={`rotate(${ds.handle*180/Math.PI} 40 790)`}><path d="M40 790 H111" stroke="#d4c6a3" strokeWidth="9" strokeLinecap="round"/></g>
 <circle cx="40" cy="828" r="8" fill="#162b33"/>
 </g>
 <path d="M570 440 H1035" stroke="#a0ae9a" strokeWidth="12"/>
 <ellipse cx="380" cy="1110" rx="460" ry="600" fill="url(#amberPool)"/>
 <path d="M105 720 v95" stroke="#677b71" strokeWidth="14"/><path d="M72 720 H137 L127 808 H83Z" fill={amber} opacity=".8"/>
 <T x={815} y={380} center size={25} fill="#a5b5a6" letterSpacing="7">17</T>
 </g>}
export function BedroomSet({t}:any){return <g>
 <rect width="1080" height="1920" fill="url(#room)"/>
 <path d="M0 1490 L1080 1425 V1920 H0Z" fill="#132934"/>
 <path d="M0 1490 L1080 1425" stroke="#668383" strokeWidth="9"/>
 <path d="M0 1490 L1080 1425 V1920 H0Z" fill="url(#floorboard)"/>
 <path d="M0 0 L190 155 V1475 L0 1490Z" fill="#0d2432" opacity=".4"/>
 <rect x="610" y="330" width="370" height="700" fill="#091a2b" stroke="#8ba39a" strokeWidth="15"/>
 <rect x="630" y="350" width="330" height="660" fill="url(#glassNew)"/>
 <path d="M793 350 V1010 M630 680 H960" stroke="#536e79" strokeWidth="10"/>
 <path d={`M580 290 H695 Q${675+Math.sin(t*.8)*3} 650 710 1100 H568Z M1010 290 H906 Q${938+Math.sin(t*.8)*2} 650 908 1100 H1025Z`} fill="#2b4b50" stroke="#688680" strokeWidth="5"/>
 <path d="M570 278 H1034" stroke="#97a69a" strokeWidth="11"/>
 <path d="M-80 1500 Q130 1420 326 1510 L408 1860 H-90Z" fill="#35545a" stroke="#7a9189" strokeWidth="7"/>
 <path d="M-50 1500 Q130 1455 290 1525 L310 1600 H-56Z" fill="#79918b"/>
 <path d="M-60 1680 Q160 1600 355 1688 M65 1570 L90 1880 M240 1600 L280 1860" stroke="#1b3a46" strokeWidth="6" opacity=".5" fill="none"/>
 <path d="M-65 1840 V1920 M365 1840 V1910" stroke="#071522" strokeWidth="20"/>
 <path d="M555 1435 H775 L800 1645 H535Z" fill="#34454a" stroke="#7e9189" strokeWidth="5"/>
 <path d="M555 1435 L578 1400 H790 L775 1435Z" fill="#5e706c" stroke="#8b9b8f" strokeWidth="3"/>
 <path d="M571 1495 H762 M568 1558 H770" stroke="#677e79" strokeWidth="4"/><circle cx="668" cy="1478" r="5" fill="#b4bd9f"/>
 <ellipse cx="750" cy="1230" rx="260" ry="410" fill="url(#amberPool)"/>
 <path d="M745 1405 V1200 M716 1405 H774" stroke="#8f8a6c" strokeWidth="8"/>
 <path d="M698 1100 H790 L814 1208 H677Z" fill={amber} stroke="#b99a78" strokeWidth="3"/>
 <path d="M570 1648 L813 1648 L900 1770 H615Z" fill="#030e1a" opacity=".24"/>
 </g>}
