import React from 'react';
import {clamp,ease,blend} from './motion';
type V={x:number,y:number,z:number};
export function curve(u:number){u=clamp(u);let v=1-u;return {x:v**3*-15+3*v*v*u*-2,z:3*v*u*u*2+u**3*15};}
function derivative(u:number){let v=1-u;return {x:3*v*v*13+6*v*u*2,z:6*v*u*2+3*u*u*13};}
const table=Array.from({length:401},(_,i)=>{let u=i/400;return {u,...curve(u),distance:0};});
for(let i=1;i<table.length;i++)table[i].distance=table[i-1].distance+Math.hypot(table[i].x-table[i-1].x,table[i].z-table[i-1].z);
export const routeLength=table.at(-1)!.distance;
export function routeAt(distance:number){
 distance=clamp(distance,0,routeLength);let i=table.findIndex(p=>p.distance>=distance);if(i<1)i=1;
 let a=table[i-1],b=table[i],u=blend(a.u,b.u,(distance-a.distance)/(b.distance-a.distance));
 let p=curve(u),d=derivative(u),before=derivative(clamp(u-.001)),after=derivative(clamp(u+.001));
 const dd={x:(after.x-before.x)/.002,z:(after.z-before.z)/.002};
 const curvature=(d.x*dd.z-d.z*dd.x)/(Math.hypot(d.x,d.z)**3);
 return {...p,u,distance,yaw:Math.atan2(d.z,d.x),steer:Math.atan(2.8*curvature)};
}
const odoSamples=Array.from({length:1201},(_,i)=>({distance:routeLength*i/1200,k:Math.tan(routeAt(routeLength*i/1200).steer)/2.8}));
const odo=new Map<string,number[]>();
for(const front of [false,true])for(const z of [-.96,.96]){
 const values=[0];
 for(let i=1;i<odoSamples.length;i++){
  const k=(odoSamples[i].k+odoSamples[i-1].k)/2,ds=odoSamples[i].distance-odoSamples[i-1].distance;
  values.push(values[i-1]+ds*Math.hypot(1-z*k,front?3.1*k:0));
 }
 odo.set(String(front)+z,values);
}
export function wheelTravel(distance:number,front:boolean,z:number){
 const u=clamp(distance/routeLength)*1200,i=Math.min(1199,Math.floor(u));
 const v=odo.get(String(front)+z)!;return blend(v[i],v[i+1],u-i);
}
export const project=(p:V)=>({x:600+(p.x-p.z*.45)*52,y:1070+(p.z*.38-p.y*.9)*52});
const points=(ps:V[])=>ps.map(p=>{let q=project(p);return `${q.x},${q.y}`}).join(' ');
export function PerspectiveRoad(){
 const road=Array.from({length:70},(_,i)=>{let u=i/69,p=curve(u),d=derivative(u),l=Math.hypot(d.x,d.z);return {p,n:{x:-d.z/l,z:d.x/l}}});
 const edge=(side:number,width:number)=>road.map(({p,n})=>({x:p.x+n.x*width*side,z:p.z+n.z*width*side,y:0}));
 return <g>
 <polygon points={points([...edge(1,4.1),...edge(-1,4.1).reverse()])} fill="#627577"/>
 <polygon points={points([...edge(1,3.5),...edge(-1,3.5).reverse()])} fill="#314c58"/>
 <polygon points={points([...edge(1,3.1),...edge(-1,3.1).reverse()])} fill="url(#wet)" stroke="#8d9c8c" strokeWidth="3"/>
 {Array.from({length:14},(_,i)=>{let a=routeAt(i*routeLength/14),b=routeAt((i+.45)*routeLength/14);return <path key={i} d={`M${project({x:a.x,z:a.z,y:.005}).x} ${project({x:a.x,z:a.z,y:.005}).y} L${project({x:b.x,z:b.z,y:.005}).x} ${project({x:b.x,z:b.z,y:.005}).y}`} stroke="#bcc4ab" strokeWidth="3"/>})}
 </g>
}
export function PerspectiveCar({distance,blue=false}:any){
 const r=routeAt(distance),co=Math.cos(r.yaw),si=Math.sin(r.yaw),heave=Math.sin(distance*2)*.012;
 const wp=(x:number,y:number,z:number):V=>({x:r.x+co*(x+1.55)-si*z,y:y+heave,z:r.z+si*(x+1.55)+co*z});
 const polygon=(id:string,ps:number[][],color:string,stroke='#70898d')=>({id,ps:ps.map(p=>wp(...p as [number,number,number])),color,stroke});
 const body=blue?'#285160':'#111e2b',side=blue?'#1a3c4c':'#09131e',top=blue?'#4a7380':'#2b414c';
 const faces=[
 polygon('body-front',[[2.4,.42,-.92],[2.4,1.0,-.92],[2.4,1.0,.92],[2.4,.42,.92]],body),
 polygon('side-near',[[-2.4,.42,.92],[-2.4,1,.92],[2.4,1,.92],[2.4,.42,.92]],side),
 polygon('side-far',[[-2.4,.42,-.92],[-2.4,1,-.92],[2.4,1,-.92],[2.4,.42,-.92]],side),
 polygon('hood',[[1.25,1,-.92],[2.4,1,-.92],[2.4,1,.92],[1.25,1,.92]],top),
 polygon('trunk',[[-2.4,1,-.92],[-1.65,1,-.92],[-1.65,1,.92],[-2.4,1,.92]],top),
 polygon('roof',[[-1.0,1.7,-.76],[.55,1.7,-.76],[.55,1.7,.76],[-1.0,1.7,.76]],top),
 polygon('windshield',[[.55,1.7,-.76],[1.25,1,-.92],[1.25,1,.92],[.55,1.7,.76]],'#264b59'),
 polygon('rear-glass',[[-1.65,1,-.92],[-1,1.7,-.76],[-1,1.7,.76],[-1.65,1,.92]],'#1e3b4b'),
 polygon('window-near',[[-1.65,1,.92],[-1,1.7,.76],[.55,1.7,.76],[1.25,1,.92]],'#1e3f50'),
 polygon('window-far',[[-1.65,1,-.92],[-1,1.7,-.76],[.55,1.7,-.76],[1.25,1,-.92]],'#173341'),
 ];
 const wheel=(x:number,z:number)=>{
  let curvature=Math.tan(r.steer)/2.8,steer=x>0?Math.atan(3.1*curvature/(1-z*curvature)):0,roll=-wheelTravel(distance,x>0,z)/.4;
  const center=wp(x,.4-heave,z);
  const local=(a:number,rad=.4)=>{let dx=Math.cos(a)*rad,dy=Math.sin(a)*rad;return wp(x+dx*Math.cos(steer),.4+dy-heave,z+dx*Math.sin(steer))};
  const rim=Array.from({length:33},(_,i)=>local(i/32*Math.PI*2));
  let c=project(center);
  return <g key={x+','+z}><polygon points={points(rim)} fill="#030a11" stroke="#526c76" strokeWidth="3"/>{[0,Math.PI/3,Math.PI*2/3].map((a,i)=>{let p=project(local(a+roll,.25)),q=project(local(a+roll+Math.PI,.25));return <path key={i} d={`M${p.x} ${p.y} L${q.x} ${q.y}`} stroke="#92a29d" strokeWidth="3"/>})}<circle cx={c.x} cy={c.y} r="3" fill="#b6c5b3"/></g>
 };
 const ground=(x:number,z:number)=>({...wp(x,0,z),y:.005});
 const lamp=(z:number)=>{let a=wp(2.41,.84,z-.16),b=wp(2.41,.84,z+.16);let pa=project(a),pb=project(b);return <path key={z} d={`M${pa.x} ${pa.y} L${pb.x} ${pb.y}`} stroke="#d4ebc9" strokeWidth="5"/>};
 faces.sort((a,b)=>a.ps.reduce((v,p)=>v+p.z+p.x*.3,0)/a.ps.length-b.ps.reduce((v,p)=>v+p.z+p.x*.3,0)/b.ps.length);
 return <g>
 <polygon points={points([ground(-2.6,-1.1),ground(2.6,-1.1),ground(2.6,1.1),ground(-2.6,1.1)])} fill="#010a12" opacity=".65"/>
 <polygon points={points([ground(2.45,-.8),ground(9,-2),ground(9,2),ground(2.45,.8)])} fill="#d6d7af" opacity=".10"/>
 {wheel(-1.55,-.96)}{wheel(1.55,-.96)}
 {faces.map(f=><polygon key={f.id} points={points(f.ps)} fill={f.color} stroke={f.stroke} strokeWidth="1.7" strokeLinejoin="round"/>)}
 {wheel(-1.55,.96)}{wheel(1.55,.96)}{lamp(-.65)}{lamp(.65)}
 </g>
}
