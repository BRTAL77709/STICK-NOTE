import React from 'react';
import {Head,L} from './OriginalArt';
import {P,actorPose} from './motion';
export type Pose=ReturnType<typeof actorPose>;
const str=(p:P)=>`${p.x},${p.y}`;
export function Character({pose:p,contact=false}: {pose:Pose,contact?:boolean}){
 const {s,ground,root}=p;
 const limb=(bone:any,arm:boolean)=><g>
  <L p={[bone.a,bone.joint,bone.end].map(str).join(' ')} w={(arm?26:28)*s}/>
  {arm&&<L p={[bone.a,bone.joint,bone.end].map((q:P)=>`${q.x+4*s},${q.y-2*s}`).join(' ')} w={2*s} c="#507a80"/>}
 </g>;
 return <g>
  <ellipse cx={p.x+15*s} cy={ground+3*s} rx={135*s} ry={16*s} fill="#01070d" opacity=".7"/>
  {limb(p.leftLeg,false)}{limb(p.rightLeg,false)}
  {[p.left,p.right].map((f,i)=><L key={i} p={`${str(f.heel)} ${str(f.toe)}`} w={23*s} c="#030b14"/>)}
  <g transform={`translate(${root.x} ${root.y}) scale(${s}) rotate(${p.lean*180/Math.PI} 0 237)`}>
   <path d="M-46 69 Q0 48 48 70 L66 230 Q0 259 -65 230Z" fill="url(#hood)" stroke="#456c72" strokeWidth="3"/>
   <path d="M-43 74 Q0 124 43 74 L20 59 H-23Z" fill="#0c1822" stroke="#758e84" strokeWidth="2"/>
   <path d="M-25 94 L-12 164 M25 94 L12 164 M-35 192 Q0 176 35 192 L30 217 H-30Z" fill="none" stroke="#67837d" strokeWidth="2"/>
  </g>
  {limb(p.leftArm,true)}{limb(p.rightArm,true)}
  <circle cx={p.leftArm.end.x} cy={p.leftArm.end.y} r={13*s} fill="url(#skin)"/>
  <g transform={`translate(${p.rightArm.end.x} ${p.rightArm.end.y}) rotate(${(p.handAngle||0)*180/Math.PI})`}>
   <circle r={13*s} fill="url(#skin)"/>
   {contact&&<path d={`M${-7*s} ${-4*s} h${13*s} m${-12*s} ${6*s} h${11*s}`} fill="none" stroke="#648780" strokeWidth={1.6*s}/>}
  </g>
  <g transform={`translate(${root.x} ${root.y}) scale(${s}) rotate(${p.lean*180/Math.PI} 0 237)`}>
   <Head t={p.t} look={p.look||0} up={p.up||0} fear={p.fear||0} turn={p.head||0}/>
  </g>
 </g>
}
