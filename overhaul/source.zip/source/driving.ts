import {twoBone,ease,blend} from './motion';
export function driverState(t:number){
 const up=ease((t-.35)/.65)*(1-ease((t-2.25)/.5)),fear=ease((t-1.1)/.8),angle=(Math.sin(t*.8)*3+ease((t-2.2)/.6)*7)*Math.PI/180;
 const grip=(a:number)=>({x:500+Math.cos(a+angle)*155,y:1340+Math.sin(a+angle)*155});
 const a=grip(-2.4),b=grip(-.7),breath=Math.sin(t*(2.2+fear*2))*1.5;
 const shoulderL={x:305,y:1175+breath},shoulderR={x:415,y:1175+breath};
 const arms=[twoBone(shoulderL,a,137.5,143.75,{x:230,y:1340},1),twoBone(shoulderR,b,137.5,143.75,{x:525,y:1380},1)];
 return {up,fear,angle,a,b,breath,arms,gap:blend(12,6,ease(t/3))};
}
