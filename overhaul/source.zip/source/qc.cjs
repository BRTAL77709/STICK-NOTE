const fs=require('fs'),path=require('path'),crypto=require('crypto');
const root=path.resolve(__dirname,'..'),out=path.join(root,'output');
const m=require(path.join(out,'motion.cjs')),d=require(path.join(out,'driving.cjs')),v=require(path.join(out,'vehicle.cjs'));
let report={sample_rate_hz:120,rig:{},driver:{},vehicle:{},approval:'Pending user review. Preview only; full-film integration is not claimed.'};
for(const [name,fn,duration] of [['door',m.doorActor,6],['run',m.runActor,3],['phone',m.phoneActor,5]]){
 let reach=0,length=0,contact=0,penetration=0,jump=0,prev=null,propError=0;
 for(let f=0;f<=duration*120;f++){
  let t=f/120,p=fn(t);
  for(const key of ['leftLeg','rightLeg','leftArm','rightArm']){
   let b=p[key],ls=key.includes('Leg')?[90,86]:[110,115];reach=Math.max(reach,b.error);
   length=Math.max(length,Math.abs(b.upper-ls[0]*p.s),Math.abs(b.lower-ls[1]*p.s));
   if(prev)jump=Math.max(jump,m.len(m.sub(b.joint,prev[key].joint)));
  }
  for(const foot of [p.left,p.right]){
   penetration=Math.max(penetration,Math.max(foot.heel.y,foot.toe.y)+11.5*p.s-p.ground);
   if(foot.planted){let q=foot.phase==='toe-off'?foot.toe:foot.heel;contact=Math.max(contact,Math.abs(q.x-foot.contact.x),Math.abs(q.y+11.5*p.s-foot.contact.y));}
  }
  if(name==='door'&&t>=3.55)propError=Math.max(propError,m.len(m.sub(p.rightArm.end,m.doorState(t).grip)));
  if(name==='phone'&&t>=1.65)propError=Math.max(propError,m.len(m.sub(p.rightArm.end,m.phoneState(t).wrist)));
  prev=p;
 }
 if(reach>.01||length>.0001||contact>.0001||penetration>.001||propError>.01||jump>12)throw Error('Kinematic check failed: '+name);
 report.rig[name]={max_reach_error_px:reach,max_limb_length_error_px:length,max_planted_contact_error_px:contact,max_floor_penetration_px:penetration,max_prop_contact_error_px:propError,max_joint_step_at_120hz_px:jump};
}
let armError=0,rimError=0,driverJointJump=0,prev;
for(let f=0;f<=360;f++){
 let p=d.driverState(f/120);
 for(let i=0;i<p.arms.length;i++){let a=p.arms[i];armError=Math.max(armError,a.error);if(prev)driverJointJump=Math.max(driverJointJump,m.len(m.sub(a.joint,prev.arms[i].joint)));}
 for(let q of [p.a,p.b])rimError=Math.max(rimError,Math.abs(Math.hypot(q.x-500,q.y-1340)-155));prev=p;
}
if(armError>.01||rimError>.001||driverJointJump>12)throw Error('Driver check failed');
report.driver={max_arm_reach_error_px:armError,max_hand_to_wheel_rim_error_px:rimError,max_joint_step_at_120hz_px:driverJointJump,mirror_gap_m_start_end:[12,6]};
let lateral=0,steer=0;
for(let f=0;f<360;f++){
 let u=f/360,dist=v.routeLength*(.2+.4*(u+.07*Math.sin(2*Math.PI*u))),p=v.routeAt(dist),speed=v.routeLength*.4/3*(1+.14*Math.PI*Math.cos(2*Math.PI*u)),k=Math.tan(p.steer)/2.8;
 lateral=Math.max(lateral,speed*speed*Math.abs(k));
 for(let z of [-.96,.96])steer=Math.max(steer,Math.abs(Math.atan(3.1*k/(1-z*k)))*180/Math.PI);
}
report.vehicle={route_length_m:v.routeLength,shared_rear_axle_route_gap_m:6,max_lateral_acceleration_m_s2:lateral,max_ackermann_front_wheel_steer_degrees:steer,wheel_radius_m:.4,wheel_rotation:'negative integrated per-wheel travel / radius; inner and outer travel differ',suspension:'body-only heave; wheel bottoms stay on road plane'};
const old=fs.readFileSync(path.join(root,'preserved/Film.baseline.tsx'),'utf8'),art=fs.readFileSync(path.join(root,'source/OriginalArt.tsx'),'utf8');
function head(s){return s.slice(s.indexOf('function Head('),s.indexOf('function Rig('));}
if(head(old)!==head(art))throw Error('Original head artwork changed');
const hashes=JSON.parse(fs.readFileSync(path.join(root,'preserved/original-hashes.json')));
for(const [name,hash]of Object.entries(hashes)){if(crypto.createHash('sha256').update(fs.readFileSync(name)).digest('hex')!==hash)throw Error('Preserved original changed: '+name);}
report.preservation={head_artwork_identical:true,original_files_hash_verified:Object.keys(hashes)};
fs.writeFileSync(path.join(out,'kinematics-qc.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
