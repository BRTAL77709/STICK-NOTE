# Codex agent — cinematic animated stickman director

User has rejected multiple static-slide videos. Prioritize **credible character acting, camera blocking, legible smartphone POV, and professional English audio** over speed and filesize. Work autonomously; don't ask for preferences already specified.

Read `README.md`, `PRODUCTION_PIPELINE.md`, `storyboard.json`, `narration.txt`. Run `python check_environment.py` and `python setup_tools.py --clone`, then inspect HyperFrames, Kokoro and Vanta actual capabilities, licenses and installation requirements. Never fabricate repository features or claim tools were installed when they weren't.

Create a true animated original 9:16 1080x1920, 30fps horror story, 45–60s, with 2D stickman puppet, black hoodie/cap, teal/amber cinematic lighting, POV phone message at 3:17 AM from 'Me', three knocks, second warning, whisper, and a bold RUN / OPEN THE DOOR audience vote. Animate limb articulation, breathing, eyes, interaction, shadows, lighting, and camera movement. Build the 8-second proof shot first, inspect, then complete full film. Use Kokoro for English voice only if actual listening QA passes. Make Foley and original or licensed background score. Subtitles synced to voice. Export H.264/AAC MP4, SRT, QA report, scene frames/contact sheet and source. Check ffprobe, audio clipping, spelling, phone readability and spatial continuity.

Do not pass off slideshow animation as a finished movie. If essential GPU/API/network dependency is unavailable, document exact blocker and still deliver best independently verifiable assets; never pretend a complete cinematic render exists.
