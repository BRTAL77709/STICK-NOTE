#!/usr/bin/env python3
"""Clone production references, inspect rather than blindly execute their code."""
import argparse, pathlib, subprocess
ROOT=pathlib.Path(__file__).resolve().parent
REPOS={"hyperframes":"https://github.com/heygen-com/hyperframes.git","kokoro":"https://github.com/hexgrad/kokoro.git","vanta":"https://github.com/itsjwill/vanta.git"}
p=argparse.ArgumentParser();p.add_argument('--clone',action='store_true');a=p.parse_args()
for name,url in REPOS.items():
    target=ROOT/'external'/name
    if not a.clone:
        print(f'{name}: {url} (run --clone to fetch)');continue
    if target.exists(): print(f'{name}: exists, inspect before updating');continue
    target.parent.mkdir(parents=True,exist_ok=True)
    subprocess.run(['git','clone','--depth','1',url,str(target)],check=True)
    print(f'Cloned {name}; read README, LICENSE, and dependency files before running installers')
