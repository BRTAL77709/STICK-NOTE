# Codex production pipeline — quality first

## Tools and limitations
- **HyperFrames**: inspect its actual API, supported animation primitives, renderer and license. Do not assume it is an AI character animation model.
- **Kokoro**: local TTS candidate. Benchmark available English voices and record best take; pronunciation, pacing and emotion must be judged by listening. Kokoro alone does not guarantee cinematic acting.
- **Vanta**: inspect actual README and examples before choosing its role. If unsuitable, use Remotion + SVG/Canvas for deterministic character animation and FFmpeg for finishing.
- **FFmpeg/ffprobe**: final audio mix, mastering, encoding, QC.
- **Optional image/video generative models**: only use with working API credentials and rights. No promises of Higgsfield-level motion without working models.

## Required build sequence
1. Run `python check_environment.py` and `python setup_tools.py --clone`. Read all three repositories' READMEs and licenses. If clone fails, report network issue.
2. Implement a **real rigged stickman** with layered head/torso/arms/hands/legs, IK or per-joint animation, lip/breath/eye states. Create reusable room, bed, door, phone assets; no stock people.
3. Produce an 8-second **proof shot first**: third-person character sits up, blinks, reaches for a vibrating phone, camera moves, screen glows. Inspect real motion before building the whole film.
4. Produce a **POV phone shot** with a visibly held phone, hand and subtle camera shake. Phone UI should show a plausible local number and contact `Me`, but do not display an actual person's phone number. Message text must be legible at phone size.
5. Generate narrator with Kokoro and compare at least two available voices. Add dramatic pauses, split lines for control, correct robotic phrasing. Make separate whispered dialogue. If unacceptable, stop and request a better voice model rather than shipping bad audio.
6. Record/generate original Foley: buzz, exactly 3 knocks, room tone, cloth, footsteps, hinge, low suspense score. Mix speech clearly above music; no clipping.
7. Use storyboard timecodes as rough targets, not forced timings. Edit for retention: immediate inciting incident, visual change every 2–4 seconds where motivated, one clean cliffhanger, vote on screen 4+ seconds.
8. Export `output/unknown_number_part1.mp4`, `output/unknown_number_part1.srt`, `output/qa.md`, and a contact sheet. Test phone legibility, audio and character consistency at mobile size.

## Original English narration (adapt timing to performance)
"At 3:17 in the morning, my phone started buzzing. The caller wasn't unknown. It was me. Then a text appeared: 'Don't open your bedroom door.' I live alone. So why did I hear three knocks? Another message. 'That's not your mother.' The handle started turning. And from the other side, I heard my own voice: 'Please... let me in.' I have seconds to decide. RUN... or OPEN THE DOOR? Comment your choice. The majority decides part two."

## Production gate
Reject output if: static image zoom montage, motionless character, phone not readable, synthetic voice distractingly robotic, narration buried by music, fewer than three audible knocks, or no obvious RUN/OPEN vote. A 10 MB file is not a quality requirement; bitrate/size depend on content and duration.
