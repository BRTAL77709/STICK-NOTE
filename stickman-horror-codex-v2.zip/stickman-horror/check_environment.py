import shutil, importlib.util, subprocess, json
for binary in ('git','node','npm','ffmpeg','ffprobe','python'):
    print(f'{binary}: {shutil.which(binary) or "MISSING"}')
for module in ('torch','kokoro','PIL','moviepy'):
    print(f'{module}: {bool(importlib.util.find_spec(module))}')
try:
    import torch
    print('CUDA available:', torch.cuda.is_available())
except Exception:
    print('CUDA status: unknown')
