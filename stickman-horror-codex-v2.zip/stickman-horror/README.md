# THE UNKNOWN NUMBER — Cinematic Stickman Horror

## Goal
Produce an ORIGINAL, 45–60-second, 1080x1920, 30 fps, H.264/AAC horror short, in a consistent illustrated stickman cinematic style. This project is a Codex-ready production brief, **not a finished film**.

## Quick start in Codex
1. Open this folder in Codex (or a coding agent with terminal access).
2. Read `AGENTS.md`, `storyboard.json`, and `narration.txt`.
3. Install and inspect the real repositories before selecting an architecture:
   - https://github.com/heygen-com/hyperframes
   - https://github.com/hexgrad/kokoro
   - https://github.com/itsjwill/vanta
4. Run `python check_environment.py` and report available dependencies, GPU and API keys (never print secrets).
5. Follow `AGENTS.md` and render `output/unknown_number_part1.mp4`.

## Required result
- NOT a Ken Burns slideshow or poster sequence.
- Character animation, hand-to-phone interaction, eye and head movement, consistent room layout.
- Realistic legible phone UI showing own number and messages.
- First-person phone shots intercut with third-person animated character shots.
- Natural expressive English voice; do not substitute low-quality robotic narration without disclosure.
- Foley, suspenseful original/royalty-cleared music, subtitle timing and orange/white voting UI.
- Verify with ffprobe and contact sheet of frames.

## Honest status
Scaffold and production plan only. Dependencies have not been installed and no new video has been rendered by this scaffold.

## Expanded Codex setup (v2)
Run `python setup_tools.py --clone` to fetch HyperFrames, Kokoro, and Vanta into `external/`. This **only clones** them; dependencies and model weights require their actual documentation. Read `PRODUCTION_PIPELINE.md` for the proof-shot gate, voice audition, full animation and QA workflow. Do not post unreviewed drafts.
